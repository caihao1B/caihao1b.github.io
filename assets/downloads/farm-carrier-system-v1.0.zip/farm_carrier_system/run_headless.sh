#!/usr/bin/env sh
set -eu
TASK_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
cd "$TASK_DIR"
exec java -jar farm-carrier.jar --headless "$@"
