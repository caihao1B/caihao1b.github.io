@echo off
setlocal
cd /d "%~dp0"
where java >nul 2>nul
if errorlevel 1 (
  echo Java is not installed or is not on PATH. Install Java 17 and see README_ZH.md.
  pause
  exit /b 1
)
java -jar farm-carrier.jar %*
if errorlevel 1 pause
