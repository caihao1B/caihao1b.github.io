package farm.sim;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/** Dependency-free, behavioural regression suite. Run with java -cp ... farm.sim.CoreTests. */
public final class CoreTests {
    private static int passed;
    private static final List<Object> results=new ArrayList<Object>();
    private static void require(boolean b,String message){if(!b)throw new AssertionError(message);}
    @SuppressWarnings("unchecked") private static Map<String,Object> map(Object v){return(Map<String,Object>)v;}
    private static double n(Map<String,Object>m,String k){return((Number)m.get(k)).doubleValue();}
    private static String status(MissionEngine e){return String.valueOf(e.snapshot().get("status"));}
    private static Map<String,Object> unitMap(){
        return Json.object("{\"origin_wgs84\":[10,52],\"depot\":[-20,0],\"fields\":[{\"id\":\"unit_field\",\"name\":\"Unit rectangle\",\"polygon\":[[0,0],[120,0],[120,80],[0,80]],\"staging\":[0,0],\"entry\":[0,0],\"access_path\":[[0,0],[3,0]],\"access_corridor\":[[-3,-3],[6,-3],[6,3],[-3,3]]}],\"roads\":[{\"id\":\"road\",\"points\":[[-20,0],[0,0]],\"source\":\"synthetic_test\"}],\"obstacles\":[],\"simulation\":{\"robot_material_kg\":1,\"carrier_supply_kg\":30,\"robot_battery_kwh\":0.12,\"battery_reserve_kwh\":0.02,\"unload_seconds\":2,\"load_seconds\":2,\"service_min_seconds\":2}}");
    }
    private static void run(MissionEngine e,double limit){
        int loops=(int)Math.ceil(limit/30);
        for(int i=0;i<loops&&!e.isTerminal()&&status(e).equals("RUNNING");i++)e.tick(30);
    }
    private static void completed(MissionEngine e,String name){
        require(status(e).equals("COMPLETED"),name+" did not complete: "+Json.stringify(e.snapshot()));
        Map<String,Object>s=e.snapshot(),v=map(e.metrics().get("validation"));
        require(n(map(s.get("coverage")),"fraction")==1,name+" incomplete coverage");
        require(Boolean.TRUE.equals(v.get("onboardAtFinish")),name+" missing robots at finish");
        require(((List<?>)e.metrics().get("invariantViolations")).isEmpty(),name+" invariant violation");
        require(Math.abs(n(v,"resourceConservationErrorKWh"))<1e-6,name+" energy balance");
        require(Math.abs(n(v,"materialConservationErrorKg"))<1e-6,name+" material balance");
        require(Math.abs(n(v,"cargoConservationErrorKg"))<1e-6,name+" cargo balance");
        require(n(map(s.get("carrier")),"x")==-20||name.startsWith("real_"),"Unit carrier not back at depot");
    }
    private static void record(String name,MissionEngine e){passed++;Map<String,Object>r=new LinkedHashMap<String,Object>();r.put("test",name);r.put("result","PASS");if(e!=null){r.put("status",status(e));r.put("metrics",e.metrics());}results.add(r);System.err.println("PASS "+name);}
    private static void geometryTests(){
        List<Geometry.Point> p=Geometry.points(Json.parse("[[0,0],[8,0],[8,2],[2,2],[2,8],[0,8]]"));
        Geometry.Point a=new Geometry.Point(1,7),b=new Geometry.Point(7,1);
        require(!Geometry.segmentInside(a,b,p),"Concave outside shortcut admitted");
        List<Geometry.Point> path=Geometry.pathInside(a,b,p);require(path.size()>2,"Concave path should bend");
        for(int i=1;i<path.size();i++)require(Geometry.segmentInside(path.get(i-1),path.get(i),p),"Visibility path exits polygon");
        for(List<Geometry.Point> l:Geometry.strips(p,1))require(Geometry.segmentInside(l.get(0),l.get(1),p),"Coverage segment outside polygon");
        boolean rejected=false;Map<String,Object> bad=unitMap();bad.put("roads",new ArrayList<Object>());try{new MissionEngine(bad,"normal",3);}catch(IllegalArgumentException x){rejected=true;}require(rejected,"Disconnected roads must be rejected");
        rejected=false;bad=unitMap();bad.put("obstacles",Arrays.asList(Collections.singletonMap("id","unhandled")));try{new MissionEngine(bad,"normal",3);}catch(IllegalArgumentException x){rejected=true;}require(rejected,"Unhandled obstacles must be rejected");
        record("geometry_concave_and_invalid_route",null);
    }
    private static void normalTests(){
        for(String scenario:Arrays.asList("normal","baseline","low_battery","harvest")){
            MissionEngine e=new MissionEngine(unitMap(),scenario,3);run(e,30000);completed(e,"unit_"+scenario);
            if(!scenario.equals("harvest"))require(n(e.metrics(),"serviceCycles")>0,"Expected real resource service cycle");
            if(scenario.equals("harvest"))require(n(e.metrics(),"harvestedKg")>0,"Harvest must produce and offload cargo");
            record("unit_"+scenario,e);
        }
        MissionEngine one=new MissionEngine(unitMap(),"normal",1);run(one,30000);completed(one,"unit_one_robot");record("unit_one_robot",one);
    }
    private static void faultTests(){
        MissionEngine f=new MissionEngine(unitMap(),"robot_fault",3);run(f,30000);require(status(f).equals("WAITING_RECOVERY"),"Fault must latch recovery wait");double t=n(f.snapshot(),"time");f.tick(500);require(n(f.snapshot(),"time")==t,"Fault must freeze model progression");
        f.command("clear_route",null);require(status(f).equals("WAITING_RECOVERY"),"Route clear must not reset device fault");
        String faulted=null;for(Object r:(List<?>)f.snapshot().get("robots"))if(map(r).get("state").equals("FAULT"))faulted=(String)map(r).get("id");require(faulted!=null,"Faulted actor not identified");
        f.command("clear_fault",faulted);run(f,30000);completed(f,"unit_fault_recovery");record("unit_fault_recovery",f);
        MissionEngine b=new MissionEngine(unitMap(),"blocked_return",3);run(b,30000);require(status(b).equals("WAITING_RECOVERY"),"Blocked return must not claim completion");b.command("clear_route",null);run(b,30000);completed(b,"unit_block_recovery");record("unit_block_recovery",b);
        MissionEngine r=new MissionEngine(unitMap(),"normal",3);r.tick(80);r.command("recall",null);run(r,30000);require(status(r).equals("CANCELLED"),"Recall must report CANCELLED");require(Boolean.TRUE.equals(map(r.metrics().get("validation")).get("onboardAtFinish")),"Recall left robot outside carrier");require(n(map(r.snapshot().get("coverage")),"fraction")<1,"Recall should preserve unfinished work");record("unit_recall",r);
        Map<String,Object> depleted=unitMap();map(depleted.get("simulation")).put("carrier_supply_kg",0.0);MissionEngine d=new MissionEngine(depleted,"normal",3);run(d,30000);require(status(d).equals("FAILED"),"Missing material must fail honestly");require(n(map(d.snapshot().get("coverage")),"fraction")<1,"Failure must not claim full coverage");record("unit_material_depletion",d);
        Map<String,Object> tooSmall=unitMap();map(tooSmall.get("simulation")).put("robot_battery_kwh",0.025);MissionEngine impossible=new MissionEngine(tooSmall,"normal",1);run(impossible,1000);require(status(impossible).equals("FAILED"),"Infeasible mission must fail rather than service forever");record("unit_infeasible_battery",impossible);
        MissionEngine transitRecall=new MissionEngine(unitMap(),"normal",3);transitRecall.tick(1);transitRecall.command("recall",null);run(transitRecall,1000);require(status(transitRecall).equals("CANCELLED"),"Mid-road recall must route back along declared roads");record("unit_recall_during_road_transit",transitRecall);
        MissionEngine dual=new MissionEngine(unitMap(),"normal",3);dual.tick(60);dual.command("fault_robot","robot_1");dual.command("block_route",null);dual.command("clear_fault","robot_1");require(status(dual).equals("WAITING_RECOVERY"),"Fault clear must not bypass blocked route");dual.command("clear_route",null);run(dual,30000);completed(dual,"unit_dual_latch");record("unit_independent_fault_route_latches",dual);
        boolean rejected=false;Map<String,Object> tinyMaterial=unitMap();map(tinyMaterial.get("simulation")).put("robot_material_kg",0.01);
        try{new MissionEngine(tinyMaterial,"normal",3);}catch(IllegalArgumentException x){rejected=true;}require(rejected,"Material capacity below work lookahead must not enter refill livelock");
        rejected=false;Map<String,Object> tinyCargo=unitMap();map(tinyCargo.get("simulation")).put("robot_cargo_kg",0.01);
        try{new MissionEngine(tinyCargo,"harvest",3);}catch(IllegalArgumentException x){rejected=true;}require(rejected,"Cargo capacity below work lookahead must not enter offload livelock");record("unit_infeasible_payload_parameters",null);
    }
    private static void realMapTests(String file)throws Exception{
        Map<String,Object> actual=Json.object(new String(Files.readAllBytes(Paths.get(file)),StandardCharsets.UTF_8));
        for(String scenario:Arrays.asList("normal","baseline","low_battery","harvest","blocked_return","robot_fault")){
            MissionEngine e=new MissionEngine(actual,scenario,3);run(e,100000);
            if(status(e).equals("WAITING_RECOVERY")){
                if(scenario.equals("blocked_return"))e.command("clear_route",null);
                if(scenario.equals("robot_fault"))for(Object raw:(List<?>)e.snapshot().get("robots")){Map<String,Object> r=map(raw);if(r.get("state").equals("FAULT"))e.command("clear_fault",(String)r.get("id"));}
                run(e,100000);
            }
            completed(e,"real_"+scenario);require(n(e.metrics(),"serviceCycles")>0,"Actual field scenario should include service");
            // Validate every exported coverage segment against the original field boundary.
            Map<String,Object> plan=e.exportPlan();for(Object rr:(List<?>)plan.get("robots"))for(Object seg:(List<?>)map(rr).get("segments")){
                Map<String,Object>sg=map(seg);List<Geometry.Point> line=Geometry.points(sg.get("points"));List<Geometry.Point>poly=null,corridor=null;
                for(Object ff:(List<?>)actual.get("fields"))if(map(ff).get("id").equals(sg.get("field_id"))){poly=Geometry.points(map(ff).get("polygon"));corridor=Geometry.points(map(ff).get("access_corridor"));}
                require(poly!=null,"Exported unknown field");List<List<Geometry.Point>> regions=new ArrayList<List<Geometry.Point>>();regions.add(poly);if(!sg.get("kind").equals("coverage")&&corridor!=null)regions.add(corridor);
                for(int k=1;k<line.size();k++)require(Geometry.segmentInsideUnion(line.get(k-1),line.get(k),regions),"Exported segment outside allowed region");
            }
            record("real_"+scenario,e);
        }
    }
    public static void main(String[] args)throws Exception{
        geometryTests();normalTests();faultTests();if(args.length>0)realMapTests(args[0]);
        Map<String,Object> report=new LinkedHashMap<String,Object>();report.put("suite","Java 8 mission core regression");report.put("passed",passed);report.put("failed",0);report.put("tests",results);System.out.println(Json.stringify(report));
    }
}
