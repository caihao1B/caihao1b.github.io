package farm.sim;

import com.sun.net.httpserver.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.*;

/** Loopback-only dashboard and reproducible batch runner. Java 8+, no external JARs. */
public final class App {
    private final Object lock = new Object();
    private final Path home;
    private Map<String,Object> map;
    private MissionEngine engine;
    private boolean playing = false;
    private double speed = 60, accumulator = 0;
    private final String token = UUID.randomUUID().toString();
    private String scenario;
    private int robotCount;
    private static final Set<String> SCENARIOS = new LinkedHashSet<String>(Arrays.asList(
        "normal", "low_battery", "harvest", "blocked_return", "robot_fault", "baseline"));

    public static void main(String[] args) throws Exception {
        Map<String,String> opts = options(args);
        if(opts.containsKey("help")) {
            System.out.println("Farm Carrier System\n  java -jar farm-carrier.jar [--port 8765] [--no-browser]\n  java -jar farm-carrier.jar --headless --scenario normal --robots 3 --output runs/normal\nScenarios: "+SCENARIOS);
            return;
        }
        Path home=locateHome(opts.get("home"));
        String scenario=opts.getOrDefault("scenario", "normal");
        int count=Integer.parseInt(opts.getOrDefault("robots", "3"));
        checkConfig(scenario,count);
        Path mapFile=opts.containsKey("map")?Paths.get(opts.get("map")).toAbsolutePath():home.resolve("maps/farm_map.json");
        Map<String,Object> map=Json.object(new String(Files.readAllBytes(mapFile), StandardCharsets.UTF_8));
        if(opts.containsKey("parameters"))map.put("simulation",Json.object(new String(Files.readAllBytes(Paths.get(opts.get("parameters"))),StandardCharsets.UTF_8)));
        App app=new App(home,map,scenario,count);
        if(opts.containsKey("headless")) {
            double dt=Double.parseDouble(opts.getOrDefault("dt","0.5"));
            double max=Double.parseDouble(opts.getOrDefault("max-seconds","86400"));
            if(!Double.isFinite(dt)||dt<=0||dt>5||!Double.isFinite(max)||max<=0||max>604800)throw new IllegalArgumentException("dt must be (0,5], max-seconds (0,604800]");
            int steps=(int)Math.ceil(max/dt);
            for(int i=0;i<steps && app.engine.status().equals("RUNNING");i++)app.engine.tick(dt);
            Path out=opts.containsKey("output")?Paths.get(opts.get("output")).toAbsolutePath():home.resolve("runs/latest");
            app.exportRun(out);
            System.out.println(Json.stringify(app.engine.metrics()));
            System.out.println("STATUS="+app.engine.snapshot().get("status"));
            System.out.println("OUTPUT="+out);
            String status=app.engine.status();
            if(status.equals("RUNNING"))System.exit(2);
            if(status.equals("WAITING_RECOVERY"))System.exit(3);
            if(status.equals("FAILED"))System.exit(4);
            if(status.equals("CANCELLED"))System.exit(5);
            return;
        }
        int port=Integer.parseInt(opts.getOrDefault("port","8765"));
        if(port<1024||port>65535)throw new IllegalArgumentException("Port must be 1024..65535");
        app.serve(port,!opts.containsKey("no-browser"));
    }
    private App(Path home,Map<String,Object> map,String scenario,int count) {
        this.home=home;this.map=map;this.scenario=scenario;this.robotCount=count;
        engine=new MissionEngine(map,scenario,count);
    }
    private static Map<String,String> options(String[] args) {
        Map<String,String> o=new LinkedHashMap<String,String>();
        Set<String> flags=new HashSet<String>(Arrays.asList("headless","no-browser","help"));
        Set<String> keys=new HashSet<String>(Arrays.asList("home","map","parameters","scenario","robots","output","dt","max-seconds","port"));
        for(int i=0;i<args.length;i++) {
            if(!args[i].startsWith("--"))throw new IllegalArgumentException("Expected --option: "+args[i]);
            String k=args[i].substring(2);
            if(flags.contains(k))o.put(k,"true");
            else if(keys.contains(k)&&i+1<args.length)o.put(k,args[++i]);
            else throw new IllegalArgumentException("Unknown or incomplete option: "+k);
        }
        return o;
    }
    private static Path locateHome(String explicit) throws Exception {
        if(explicit!=null)return Paths.get(explicit).toAbsolutePath().normalize();
        Path cwd=Paths.get("").toAbsolutePath();
        if(Files.isRegularFile(cwd.resolve("maps/farm_map.json")))return cwd;
        Path code=Paths.get(App.class.getProtectionDomain().getCodeSource().getLocation().toURI());
        for(Path p=Files.isDirectory(code)?code:code.getParent();p!=null;p=p.getParent())
            if(Files.isRegularFile(p.resolve("maps/farm_map.json")))return p;
        throw new FileNotFoundException("Cannot locate maps/farm_map.json. Unzip the whole package and run from its folder.");
    }
    private static void checkConfig(String scenario,int count) {
        if(!SCENARIOS.contains(scenario))throw new IllegalArgumentException("Unknown scenario: "+scenario);
        if(count<1||count>4)throw new IllegalArgumentException("Robot count must be 1..4");
    }
    private void serve(int port,boolean openBrowser) throws Exception {
        HttpServer server=HttpServer.create(new InetSocketAddress(InetAddress.getByName("127.0.0.1"),port),32);
        ExecutorService requests=Executors.newFixedThreadPool(4);
        ScheduledExecutorService ticker=Executors.newSingleThreadScheduledExecutor();
        server.setExecutor(requests);
        server.createContext("/",exchange->{
            try{handle(exchange);}catch(IllegalArgumentException e){send(exchange,400,"application/json",Json.stringify(obj("error",e.getMessage())));}
            catch(Exception e){System.err.println("Request failed: "+e);send(exchange,500,"application/json",Json.stringify(obj("error",e.getClass().getSimpleName()+": "+e.getMessage())));}
            finally{exchange.close();}
        });
        ticker.scheduleAtFixedRate(()->{
            synchronized(lock){
                if(!playing)return;
                if(!engine.status().equals("RUNNING")){playing=false;accumulator=0;return;}
                try{
                    accumulator+=speed*0.1;
                    int cap=0;
                    while(accumulator>=0.5 && engine.status().equals("RUNNING") && cap++<100){engine.tick(0.5);accumulator-=0.5;}
                    if(!engine.status().equals("RUNNING")){playing=false;accumulator=0;}
                }catch(Exception e){playing=false;System.err.println("Simulation paused after exception: "+e);}
            }
        },100,100,TimeUnit.MILLISECONDS);
        Runtime.getRuntime().addShutdownHook(new Thread(()->{server.stop(0);ticker.shutdownNow();requests.shutdownNow();}));
        server.start();
        String url="http://127.0.0.1:"+port;
        System.out.println("\nFARM CARRIER SYSTEM | Java multi-agent simulation\nDashboard: "+url+"\nMap: original Feld 13 + labeled demonstration infrastructure\nPress Ctrl+C to stop. The server accepts loopback connections only.\n");
        if(openBrowser && java.awt.Desktop.isDesktopSupported())try{java.awt.Desktop.getDesktop().browse(URI.create(url));}catch(Exception ignored){}
    }
    private void handle(HttpExchange x) throws IOException {
        String path=x.getRequestURI().getPath();
        if(path.startsWith("/api/")) {
            if(path.equals("/api/command")) {
                if(!x.getRequestMethod().equals("POST")){send(x,405,"application/json","{\"error\":\"POST required\"}");return;}
                String origin=x.getRequestHeaders().getFirst("Origin");
                String expected="http://127.0.0.1:"+x.getLocalAddress().getPort();
                String expectedLocal="http://localhost:"+x.getLocalAddress().getPort();
                if("cross-site".equals(x.getRequestHeaders().getFirst("Sec-Fetch-Site")) || (origin!=null&&!origin.equals(expected)&&!origin.equals(expectedLocal)) || !token.equals(x.getRequestHeaders().getFirst("X-Farm-Token"))) {
                    send(x,403,"application/json","{\"error\":\"Use this dashboard or a valid local session token\"}");return;
                }
                Map<String,Object> request=Json.object(readBody(x.getRequestBody(),65536));
                synchronized(lock){send(x,200,"application/json",Json.stringify(command(request)));}
                return;
            }
            if(!x.getRequestMethod().equals("GET")){send(x,405,"application/json","{\"error\":\"GET required\"}");return;}
            synchronized(lock){
                if(path.equals("/api/config"))send(x,200,"application/json",Json.stringify(obj("token",token,"scenarios",SCENARIOS,"version","1.0.0","mode","simulation")));
                else if(path.equals("/api/state")){Map<String,Object>s=new LinkedHashMap<String,Object>(engine.snapshot());s.put("playing",playing);s.put("speed",speed);s.put("mode","simulation");send(x,200,"application/json",Json.stringify(s));}
                else if(path.equals("/api/map"))send(x,200,"application/json",Json.stringify(map));
                else if(path.equals("/api/plan"))send(x,200,"application/json",Json.stringify(engine.exportPlan()));
                else if(path.equals("/api/events"))send(x,200,"application/json",Json.stringify(engine.events()));
                else if(path.equals("/api/metrics"))send(x,200,"application/json",Json.stringify(engine.metrics()));
                else send(x,404,"application/json","{\"error\":\"Endpoint not found\"}");
            }
            return;
        }
        if(!x.getRequestMethod().equals("GET")){send(x,405,"text/plain","GET required");return;}
        Path ui=home.resolve("ui").normalize();
        Path f=ui.resolve(path.equals("/")?"index.html":path.substring(1)).normalize();
        if(!f.startsWith(ui)||!Files.isRegularFile(f)){send(x,404,"text/plain","Not found");return;}
        String name=f.getFileName().toString();
        String mime=name.endsWith(".html")?"text/html":name.endsWith(".js")?"text/javascript":name.endsWith(".css")?"text/css":name.endsWith(".svg")?"image/svg+xml":"application/octet-stream";
        sendBytes(x,200,mime,Files.readAllBytes(f));
    }
    private Map<String,Object> command(Map<String,Object> r) throws IOException {
        String c=String.valueOf(r.get("command"));
        if(c.equals("start")){if(engine.status().equals("RUNNING"))playing=true;}
        else if(c.equals("pause"))playing=false;
        else if(c.equals("step")){playing=false;engine.tick(0.5);}
        else if(c.equals("speed")){double v=((Number)r.get("value")).doubleValue();if(!Double.isFinite(v)||v<1||v>300)throw new IllegalArgumentException("Speed must be 1..300");speed=v;}
        else if(c.equals("reset")){
            String sc=r.containsKey("scenario")?String.valueOf(r.get("scenario")):scenario;
            int count=r.containsKey("robots")?((Number)r.get("robots")).intValue():robotCount;
            checkConfig(sc,count);MissionEngine next=new MissionEngine(map,sc,count);
            engine=next;scenario=sc;robotCount=count;playing=false;accumulator=0;
        }
        else if(c.equals("run_to_end")){
            playing=false;
            for(int i=0;i<172800&&engine.status().equals("RUNNING");i++)engine.tick(0.5);
        }
        else if(c.equals("export")){Path out=home.resolve("runs/dashboard");exportRun(out);return obj("ok",true,"message","Written to runs/dashboard", "files",Arrays.asList("metrics.json","events.csv","mission_plan.json","snapshot.json"));}
        else if(Arrays.asList("recall","fault_robot","clear_fault","block_route","clear_route").contains(c))engine.command(c,String.valueOf(r.getOrDefault("robotId","robot_1")));
        else throw new IllegalArgumentException("Unknown command: "+c);
        return obj("ok",true,"status",engine.snapshot().get("status"));
    }
    @SuppressWarnings("unchecked")
    private void exportRun(Path out) throws IOException {
        Files.createDirectories(out);
        writeJson(out.resolve("metrics.json"),engine.metrics());
        writeJson(out.resolve("snapshot.json"),engine.snapshot());
        Map<String,Object> plan=engine.exportPlan();
        writeJson(out.resolve("mission_plan.json"),plan);
        writeJson(out.resolve("events.json"),engine.events());
        Object rr=plan.get("robots");
        if(rr instanceof List)for(Object r0:(List<?>)rr){
            if(!(r0 instanceof Map))continue;
            Map<String,Object> robot=(Map<String,Object>)r0;
            String id=String.valueOf(robot.containsKey("robot_id")?robot.get("robot_id"):robot.get("id"));
            if(!id.matches("[A-Za-z0-9_-]{1,48}"))continue;
            Map<String,Object> one=new LinkedHashMap<String,Object>(plan);one.remove("robots");one.putAll(robot);one.put("robot_id",id);
            writeJson(out.resolve("plan_"+id+".json"),one);
        }
        StringBuilder csv=new StringBuilder("time,type,actor,message\r\n");
        for(Map<String,Object> event:engine.events()) {
            boolean first=true;for(String k:Arrays.asList("time","type","actor","message")){if(!first)csv.append(',');first=false;csv.append('"').append(String.valueOf(event.getOrDefault(k,"")).replace("\"","\"\"")).append('"');}csv.append("\r\n");
        }
        Files.write(out.resolve("events.csv"),csv.toString().getBytes(StandardCharsets.UTF_8));
    }
    private static void writeJson(Path p,Object value) throws IOException {Files.write(p,(Json.stringify(value)+"\n").getBytes(StandardCharsets.UTF_8));}
    private static String readBody(InputStream in,int limit) throws IOException {
        ByteArrayOutputStream b=new ByteArrayOutputStream();byte[] chunk=new byte[4096];int n;
        while((n=in.read(chunk))!=-1){if(b.size()+n>limit)throw new IllegalArgumentException("Request body too large");b.write(chunk,0,n);}return new String(b.toByteArray(),StandardCharsets.UTF_8);
    }
    private static void send(HttpExchange x,int code,String mime,String content) throws IOException {sendBytes(x,code,mime,content.getBytes(StandardCharsets.UTF_8));}
    private static void sendBytes(HttpExchange x,int code,String mime,byte[] bytes) throws IOException {
        x.getResponseHeaders().set("Content-Type",mime+(mime.startsWith("text/")||mime.equals("application/json")?"; charset=utf-8":""));
        x.getResponseHeaders().set("Cache-Control","no-store");
        x.getResponseHeaders().set("X-Content-Type-Options","nosniff");
        x.getResponseHeaders().set("Content-Security-Policy","default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'");
        x.sendResponseHeaders(code,bytes.length);x.getResponseBody().write(bytes);
    }
    static Map<String,Object> obj(Object... items){Map<String,Object> m=new LinkedHashMap<String,Object>();for(int i=0;i<items.length;i+=2)m.put((String)items[i],items[i+1]);return m;}
}
