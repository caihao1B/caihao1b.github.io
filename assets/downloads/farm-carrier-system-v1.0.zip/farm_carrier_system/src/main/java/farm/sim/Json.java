package farm.sim;

import java.lang.reflect.Array;
import java.util.*;

/** Small, dependency-free JSON codec. No script evaluation or class deserialization. */
public final class Json {
    private Json() {}
    public static Object parse(String text) {
        Reader r = new Reader(text);
        Object value = r.read(0);
        r.ws();
        if (r.i != text.length()) throw r.error("Unexpected trailing content");
        return value;
    }
    @SuppressWarnings("unchecked")
    public static Map<String,Object> object(String text) {
        Object o = parse(text);
        if (!(o instanceof Map)) throw new IllegalArgumentException("JSON object required");
        return (Map<String,Object>) o;
    }
    public static String stringify(Object value) {
        StringBuilder b = new StringBuilder();
        write(value, b);
        return b.toString();
    }
    private static void write(Object o, StringBuilder b) {
        if (o == null) b.append("null");
        else if (o instanceof String || o instanceof Character || o instanceof Enum) quote(o.toString(), b);
        else if (o instanceof Boolean) b.append(o);
        else if (o instanceof Number) {
            double n = ((Number)o).doubleValue();
            if (Double.isNaN(n) || Double.isInfinite(n)) throw new IllegalArgumentException("Non-finite JSON number");
            b.append(o);
        } else if (o instanceof Map) {
            b.append('{'); boolean first = true;
            for (Object e0 : ((Map<?,?>)o).entrySet()) {
                Map.Entry<?,?> e = (Map.Entry<?,?>)e0;
                if (!first) b.append(','); first=false;
                quote(String.valueOf(e.getKey()), b); b.append(':'); write(e.getValue(), b);
            }
            b.append('}');
        } else if (o instanceof Iterable) {
            b.append('['); boolean first=true;
            for (Object x : (Iterable<?>)o) { if(!first)b.append(','); first=false; write(x,b); }
            b.append(']');
        } else if (o.getClass().isArray()) {
            b.append('[');
            for(int i=0;i<Array.getLength(o);i++){if(i>0)b.append(',');write(Array.get(o,i),b);}
            b.append(']');
        } else throw new IllegalArgumentException("Unsupported JSON type: "+o.getClass().getName());
    }
    private static void quote(String s, StringBuilder b) {
        b.append('"');
        for(int j=0;j<s.length();j++) {
            char c=s.charAt(j);
            switch(c){
                case '"':b.append("\\\"");break;
                case '\\':b.append("\\\\");break;
                case '\n':b.append("\\n");break;
                case '\r':b.append("\\r");break;
                case '\t':b.append("\\t");break;
                case '\b':b.append("\\b");break;
                case '\f':b.append("\\f");break;
                default:if(c<32)b.append(String.format("\\u%04x",(int)c));else b.append(c);
            }
        }
        b.append('"');
    }
    private static final class Reader {
        final String s; int i;
        Reader(String s){this.s=s;}
        IllegalArgumentException error(String msg){return new IllegalArgumentException(msg+" at character "+i);}
        void ws(){while(i<s.length() && " \t\r\n".indexOf(s.charAt(i))>=0)i++;}
        Object read(int depth){
            if(depth>100)throw error("JSON nesting too deep");
            ws();if(i>=s.length())throw error("Unexpected end");char c=s.charAt(i);
            if(c=='"')return string();
            if(c=='{'){
                i++;Map<String,Object> m=new LinkedHashMap<String,Object>();ws();
                if(take('}'))return m;
                do{ws();if(i>=s.length()||s.charAt(i)!='"')throw error("Object key expected");
                    String k=string();ws();need(':');
                    if(m.containsKey(k))throw error("Duplicate key: "+k);
                    m.put(k,read(depth+1));ws();if(take('}'))return m;need(',');
                }while(true);
            }
            if(c=='['){i++;List<Object>a=new ArrayList<Object>();ws();if(take(']'))return a;
                do{a.add(read(depth+1));ws();if(take(']'))return a;need(',');}while(true);}
            if(s.startsWith("true",i)){i+=4;return true;}
            if(s.startsWith("false",i)){i+=5;return false;}
            if(s.startsWith("null",i)){i+=4;return null;}
            int start=i;if(take('-')){};
            if(take('0')) { } else {int p=i;while(i<s.length()&&Character.isDigit(s.charAt(i)))i++;if(i==p)throw error("Number expected");}
            if(take('.')){int p=i;while(i<s.length()&&Character.isDigit(s.charAt(i)))i++;if(i==p)throw error("Fraction expected");}
            if(i<s.length()&&(s.charAt(i)=='e'||s.charAt(i)=='E')){i++;if(i<s.length()&&(s.charAt(i)=='+'||s.charAt(i)=='-'))i++;int p=i;while(i<s.length()&&Character.isDigit(s.charAt(i)))i++;if(i==p)throw error("Exponent expected");}
            try{double d=Double.parseDouble(s.substring(start,i));if(Double.isNaN(d)||Double.isInfinite(d))throw error("Non-finite number");return d;}
            catch(NumberFormatException e){throw error("Invalid number");}
        }
        boolean take(char c){if(i<s.length()&&s.charAt(i)==c){i++;return true;}return false;}
        void need(char c){if(!take(c))throw error("Expected "+c);}
        String string(){need('"');StringBuilder b=new StringBuilder();while(i<s.length()){
            char c=s.charAt(i++);if(c=='"')return b.toString();if(c<32)throw error("Unescaped control character");
            if(c!='\\'){b.append(c);continue;}if(i>=s.length())throw error("Incomplete escape");
            c=s.charAt(i++);switch(c){case '"':case '\\':case '/':b.append(c);break;
                case 'n':b.append('\n');break;case 'r':b.append('\r');break;case 't':b.append('\t');break;case 'b':b.append('\b');break;case 'f':b.append('\f');break;
                case 'u':if(i+4>s.length())throw error("Incomplete unicode escape");try{b.append((char)Integer.parseInt(s.substring(i,i+4),16));}catch(NumberFormatException e){throw error("Invalid unicode escape");}i+=4;break;
                default:throw error("Invalid escape");}
        }throw error("Unterminated string");}
    }
}
