# 地图来源、坐标与演示假设

## 1. 哪些数据来自上传项目

本演示使用上传的 `verfahrenssimulation(1).7z` 内的：

`verfahrenssimulation/farms/farms_EkoTech/E4A_Kleiner Modellbetrieb_Feld13_NurDrohne.json`

原文件采用 CP1252 编码。原场景的根字段为 `name`、`jahr`、`szenario`、`locations`、`vehicles`、`attachments`、`processChains`、`fields`。选择其中唯一的 **Feld 13**，保留其全部 4 个边界顶点、3 个入口和固定农场 **Hof1** 的位置。`obstacles` 在原场景中为空。

`maps/source_field13_excerpt.json` 保存原文件中 `locations` 和 `fields` 的未修改摘录，并记录原文件 SHA-256；它没有复制原项目的数据库连接、账户配置或完整仿真源码。`maps/original_fields.geojson` 保存转换成 GeoJSON 顺序的全部原始边界、入口和 Hof1。它不包含合成道路。

原作业组合配置的 `workingWidth` 为 **9 m**，因此本演示沿用 9 m 条带间距作为默认作业幅宽。这是原场景的配置值，**不是地面机器人实际机具的标定值**。原场景中的施用无人机、60 L 药箱与本演示的地面机器人是不同的模型；地图复用并不代表两种机器有相同的硬件参数。

安全提取只把存档当数据读取，拒绝绝对路径、包含 `..` 的路径、符号链接和硬链接，排除 `.git` 和 `.idea`，没有执行旧项目。检查到 1,270 个存档条目，选择提取 581 个场景、业务源码和数据文件；没有发现被拒绝的不安全路径或链接。

## 2. 坐标顺序和米制坐标

原 JSON 的 `edgePoints`、`entrances` 和 `locations[].position` 顺序是：

```text
[latitude, longitude]  即 [纬度, 经度]
```

这个顺序可由旧项目的 `userinterface/utils/FarmParser.java` 中 `new GeoPosition(latitude, longitude)` 的读入，以及保存时先写 `getLatitude()` 再写 `getLongitude()` 的代码相互验证。原文件没有显式声明 CRS。数值与地理位置符合经纬度，本演示**按 WGS84 解释**；此项仍是依据源代码和数值作出的假定，没有现场测量或投影文件校准。

GeoJSON 改为标准的 `[longitude, latitude]` 顺序。局部米制坐标原点选择原始第一个入口：

```text
origin_wgs84 = [10.099622011184692, 52.25250200521026]
x 向东，y 向北，单位米
```

转换采用 WGS84 椭球在原点处的局部线性化：

```text
x = Δlongitude_radians × N(latitude0) × cos(latitude0)
y = Δlatitude_radians  × M(latitude0)
```

其中 N、M 分别为卯酉圈和子午圈曲率半径。这是一个供近距离工程演示使用的局部平面，**不是 UTM，也不具有一个虚构的 EPSG 代码**。地图坐标保留 6 位小数只是数值输出精度，不代表实地毫米测量精度。

转换后 Feld 13 为凸四边形，面积约 **123,875.726 m²（12.3876 ha）**。原始 Hof1 到所选入口的平面距离约 **1,730.701 m**。保留原 Hof1 的真实位置便于追溯，但没有提供它到田块的真实道路，因此默认任务不从原 Hof1 出发。

## 3. 哪些内容是为了可运行演示新增的

下列元素都是明确标注的演示假设：

| 元素 | 局部坐标 / 参数 | 用途 |
|---|---|---|
| 演示车库 `depot` | `[-55, 30]` | 运载车出发与返回的位置，在田块外 |
| 部署点 `staging` | `[0, 15]` | 运载车停车、部署与回收机器人，在田块外 |
| 入口 `entry` | `[0, 0]` | 原始第一个入口，未移动 |
| 演示道路 | `[-55,30] → [-55,20] → [0,20] → [0,15]`，宽 8 m | 连通演示车库与部署点 |
| 入口通道中心线 | `[0,15] → [0,0] → [0,-6]` | 从部署点经原入口进入田块 |
| 入口通道区域 | `[-3,18], [3,18], [3,-6], [-3,-6]`，宽 6 m | 允许机器人越过田块边界的明确区域 |

`access_path` 是中心线，`access_corridor` 是允许通行的多边形区域。两者不要混用。原农场点单独存为 `original_depot`、`original_depot_name` 和 `original_depot_wgs84`，并通过 `original_depot_used_for_mission: false` 标记不参与默认任务。

**没有把直线连接伪装成真实乡间道路，也没有从卫星照片推断可通行性。** 道路的 `source` 明确为 `synthetic demo road`。原地图的障碍列表为空，因此本演示没有凭空增加“真实障碍”；空列表也不能证明现实田块没有树、沟渠、坡度或其他限制。

## 4. 文件契约

| 文件 | 内容 |
|---|---|
| `maps/farm_map.json` | Java / 网页演示使用的局部米制地图；地块、入口、部署点、道路和来源标签 |
| `maps/farm_map.tsv` | 同一地图的轻量制表符版本，便于无 JSON 库的 Java 程序读取 |
| `maps/original_fields.geojson` | 原始经纬度边界、3 个入口及 Hof1，GeoJSON 坐标顺序为经度、纬度 |
| `maps/source_field13_excerpt.json` | 原地图的最小可重建摘录 |
| `maps/source_summary.json` | 原始源文件、哈希、schema、坐标假设、面积及验证结果 |
| `maps/map_preview.svg` | 精确矢量预览，原田块与合成通道采用不同颜色 |
| `maps/map_preview.png` | 同一几何地图的便于查看的位图预览 |
| `maps/farm_map.pgm` + `farm_map.yaml` | 合成占用栅格，可作为后续 ROS 2 map_server 接口的输入文件 |

TSV 每行有 `type, id, index, x, y` 五列，注释以 `#` 开头。`ORIGIN_WGS84` 行的最后两列是经度、纬度；其他行是局部米坐标。多边形不重复末尾首点；使用者应在几何计算时自动闭合。类型为 `FIELD`、`STAGING`、`ENTRY`、`ACCESS_PATH`、`ACCESS_CORRIDOR`、`ROAD`、`DEPOT`、`ORIGINAL_DEPOT`。

## 5. 占用栅格的含义与验证

栅格分辨率为 **1 m**，尺寸 **545 × 447**，局部左下角原点为 `[-75, -397, 0]`。原田块内部、合成道路走廊和合成入口通道为 free；其余范围为 occupied。PGM 采用从北向南的图像行顺序，YAML 的原点采用 ROS 地图常见的左下角世界坐标约定，避免上下翻转。

**这个栅格由多边形和人工设定的道路生成，是规划示例地图，既不是 SLAM 建图结果，也不是传感器实测占用地图。** 栅格中未做机器人轮廓膨胀。后续接入 ROS 2 导航时，仍需让导航系统使用正确的 footprint、膨胀参数和坐标变换；地图本身不提供真机定位或障碍感知。

生成脚本已检查：

1. 原田块是凸多边形。
2. 原入口和入口通道的田内终点位于田块中。
3. 演示车库和部署点在田块外，演示道路中心线不穿过田块。
4. 道路末端与部署点重合，入口通道通过原始入口。
5. 所有 **124,522 个 free 栅格**在四邻域下属于同一个连通分量，演示车库、部署点、入口和田内终点均在此分量内。

这些检查验证的是示例地图的几何一致性和离散连通性，不构成真实车辆可通行性认证。

## 6. 重建

在项目根目录运行，除可选的 PNG 预览外只使用 Python 标准库：

```bash
python tools/import_original_map.py
```

脚本默认读取已附带的摘录，重新生成 JSON、GeoJSON、TSV、SVG、PGM、YAML 和来源摘要。若要使用原始完整 JSON，可传入路径：

```bash
python tools/import_original_map.py "/path/to/E4A_Kleiner Modellbetrieb_Feld13_NurDrohne.json"
```

该导入脚本有意只接受本次记录的 `Feld 13`，并验证入口、凸性和空障碍列表。若换用其他地块，需要重新设计其部署点、通道和道路；脚本会拒绝无法满足约束的输入，避免默默忽略障碍或生成不连通地图。
