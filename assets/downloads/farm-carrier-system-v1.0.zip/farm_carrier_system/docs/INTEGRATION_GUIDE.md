# 接入 AnyLogic、ROS 2 Jazzy 与现有覆盖规划项目

## 1. 先明确三个运行层

| 运行层 | 这个交付包提供什么 | 已验证边界 |
|---|---|---|
| 独立 Java 仿真 | 运载车、地面机器人、任务、条带覆盖、资源、补给与回收的离散仿真；网页状态和事件 | 以根目录测试报告为准 |
| AnyLogic 接入 | 可编译 Java 8 facade、状态/位置 getters、周期事件与图形绑定代码片段 | 可在普通 Java 中检查 facade；本环境没有 AnyLogic 厂商运行时，未执行 `.alp` |
| ROS 2 / Nav2 接入 | `ament_python` 包：读取冻结的机器人路径，异步导航、结果判断、取消、超时、外部装卸确认和独立执行日志 | 无 ROS 依赖的契约/结果状态测试与 Python 语法检查；本环境没有 ROS 2、Nav2 或机器人，未端到端运行 |

**Java 仿真引擎是仿真世界的状态来源。ROS 执行器是另一套运行实例。不要让两者同时给同一实体派发任务，或把模拟移动的结果当成真机反馈。** 当前 ROS 层执行固定任务文件，不实现完整真实车队的动态资源调度、母车行驶、机械装卸、充电对接或紧急制动。

原始资料中未提供可直接修改的 AnyLogic `.alp` 模型。本包没有伪造一个未经 AnyLogic 打开验证的 `.alp`；提供的是可导入的核心 JAR 和明确的接线步骤。

## 2. 先在独立 Java 模式验证任务

项目根目录已有 `farm-carrier.jar` 时：

```bash
java -jar farm-carrier.jar
```

浏览器打开 `http://127.0.0.1:8765`。无界面导出示例：

```bash
java -jar farm-carrier.jar --headless --scenario normal --output runs/normal
```

源码重新构建用根目录 `build.bat` / `./build.sh`，根构建环境采用 JDK 17，输出 Java 8 字节码。启动用 `start.bat` / `./start.sh`。导出的 `mission_plan.json` 是车队计划；每机器人文件为 `plan_robot_1.json` 等。查看文件实际内容，确保 `robot_id`、`frame_id` 和计划坐标符合本节契约。

任务文件是一个**冻结的计划副本**。Java 仿真可动态重新分配条带，已导出的文件不会随之更新。在实机执行过程中重新替换文件不会自动触发安全重规划；执行器只在启动时读取一次。

## 3. AnyLogic 接入步骤

### 3.1 导入 JAR 与创建主变量

在你的 AnyLogic 模型依赖/Java archive 配置中加入根目录 `farm-carrier.jar`。模型树与属性面板名称会随 AnyLogic 版本变化；目标是让模型 Java 编译器能解析：

```java
farm.anylogic.AnyLogicMissionBridge
```

根构建将 facade 打进同一个 JAR，因此一般不需要另加 bridge JAR。若接入一个只包含 `farm.sim.*` 的独立核心 JAR，可单独执行：

```bash
./integrations/anylogic/build_bridge.sh /absolute/path/to/core.jar
```

Windows：

```bat
integrations\anylogic\build_bridge.bat C:\absolute\path\to\core.jar
```

随后同时导入 core JAR 和生成的 `integrations/anylogic/build/farm-anylogic-bridge.jar`。不要重复导入同一个类的两个不同版本。

在 Main 添加变量：

```java
farm.anylogic.AnyLogicMissionBridge mission;
```

添加参数 `mapFile`（String，绝对路径，例如 `C:/farm_carrier_system/maps/farm_map.json`）和 `robotCount`（int，例如 3）。Main 的 On startup 内容见 `integrations/anylogic/snippets/Main_OnStartup.java.txt`，核心为：

```java
try {
    mission = new farm.anylogic.AnyLogicMissionBridge(mapFile, "normal", robotCount);
} catch (Exception e) {
    throw new RuntimeException(e);
}
```

### 3.2 只由一个周期事件推进仿真

在 Main 添加循环 timeout 事件，间隔 **0.2 秒**，动作：

```java
if (mission != null && !mission.isTerminal()) {
    mission.tick(0.2);
}
```

`tick()` 参数总是秒。如果 AnyLogic 模型时间单位为分钟，也不要把 0.2 误当成分钟传给核心。一次 AnyLogic timeout 调用一次 `tick`；不要同时由多个 Agent 事件推进同一引擎。

### 3.3 建立可视 Agent，并绑定状态

可以创建 Carrier 与 Robot 两种 AnyLogic Agent 类型；这些类型只用于显示及交互。Robot 增加字符串参数 `id`，依次设为 `robot_1`、`robot_2`、`robot_3`。核心 getter 示例：

```java
mission.x("robot_1");
mission.y("robot_1");
mission.state("robot_1");
mission.batteryPercent("robot_1");
mission.batteryKWh("robot_1");
mission.materialKg("robot_1");
mission.cargoKg("robot_1");
mission.state("carrier");
mission.metricsJson();
```

局部地图 `+x` 向东、`+y` 向北，屏幕的 Y 通常向下。二维演示可以用像素比例 `pxPerMeter` 与屏幕原点 `ox, oy` 转换：

```java
r.setXY(ox + pxPerMeter * mission.x(r.id),
        oy - pxPerMeter * mission.y(r.id));
```

这里的 `r`、`robots`、`ox` 等是接线示例中需要你在模型里创建的名称。用 `mission.state(r.id)` 驱动颜色、文字与可见性。不要再让视觉 Agent 的 `moveTo()` 或另一套运动状态机同时更新位置，否则会出现两套运动来源。

状态机图可根据引擎状态枚举绘制为说明图。如果想让 AnyLogic statechart 真正拥有决策权，需要将核心决策规则迁移并重新做一致性测试；当前 facade 方案把可运行决策留在 Java 中，不声称已生成原生 AnyLogic statechart。

### 3.4 导出与离线检查

```java
mission.exportPlans("C:/farm_exports");
```

若只检查 facade，无需 AnyLogic：

```bash
java -cp farm-carrier.jar farm.anylogic.BridgeSmokeTest maps/farm_map.json runs/bridge_smoke normal
```

成功标识为 `ANYLOGIC_BRIDGE_SMOKE_PASS`，仅代表该 Java facade 与核心接口可运行，不代表 AnyLogic 图形模型验收。

## 4. 计划 JSON 契约

执行器接受单机器人文件，或通过 `--robot-id robot_1` 选择车队导出中的一个机器人：

```json
{
  "schema_version": 1,
  "frame_id": "map",
  "robot_id": "robot_1",
  "segments": [
    {"segment_id": "field_13_strip_0", "kind": "coverage", "points": [[2, -10], [8, -10]]},
    {"segment_id": "rendezvous", "kind": "return", "points": [[0, 15]]}
  ]
}
```

- `points` 是目标 TF 地图坐标系中的 `[x, y]`，单位米，不是经纬度，也不是图片像素。
- `coverage`：先使用 NavigateToPose 到条带起点，再将条带线性加密后交给 FollowPath。默认间隔 0.25 m，可配置。
- `transit`、`return`：各路点分别执行 NavigateToPose，具体连接路径由已配置的 Nav2 规划器生成。
- 每条 `coverage` 单独接近起点，因此不会直接跨条带画一条未经规划的连接线。但该连接路径仍依赖真实配置的 costmap、footprint、规划器与控制器。
- `segment_id` 必须唯一。拒绝 NaN、Infinity、非数字坐标和零长度覆盖路径。
- Java 导出里的 `status: COMPLETED` 只表示模拟状态，**不会被解释成真机完成，也不会被自动跳过**。恢复实际任务时，应根据 ROS 执行日志人工/程序生成剩余任务文件，并核对现场状态。
- 根车队导出可能包含 `assignment: preview_round_robin_dynamic_runtime`，这说明静态分配与模拟运行中的动态分配可能不同。ROS 运行器只执行启动时选定的固定版本。

已有 CCPP 项目需增加一个导出适配器，将它的全覆盖轨迹映射成上述结构；没有看到你最新的原项目导出 schema，因此本包不宣称无需转换即可直接导入。已有 CCPP 路径若含安全连接段，可拆成显式 `transit` 或覆盖段。还需统一机器人 footprint、作业幅宽、坐标原点、作业区域边界及障碍约束。

## 5. ROS 2 Jazzy 安装和离线验收

下列步骤面向已经安装 ROS 2 Jazzy 的 Ubuntu 24.04，并假定你的现有工作空间已经能运行对应机器人的 Nav2。这个包不替你生成完整底盘 URDF、驱动、定位、传感器、机械装卸或 Nav2 配置。

```bash
source /opt/ros/jazzy/setup.bash
mkdir -p ~/farm_ros_ws/src
cp -r /absolute/path/to/farm_carrier_system/integrations/ros2/farm_carrier_bridge ~/farm_ros_ws/src/
cd ~/farm_ros_ws
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install --packages-select farm_carrier_bridge
source install/setup.bash
```

纯 Python 离线验收，Windows 也可以运行，完全不需要 ROS：

```bash
cd /absolute/path/to/farm_carrier_system/integrations/ros2/farm_carrier_bridge
python -m unittest discover -s test -v
python -m farm_carrier_bridge.contract ../examples/plan_robot_1.json
```

验证并规范化 Java 导出的车队文件：

```bash
python -m farm_carrier_bridge.contract /absolute/path/to/runs/normal/mission_plan.json --robot-id robot_1 --output /tmp/plan_robot_1.json
```

此验证检查 schema 和任务结果判定逻辑，不检查真实 TF、障碍、路径可行性和车辆制动距离。

## 6. 接入你现有 Nav2 工作空间

### 6.1 先验证命名空间与地图

机器人 `robot_1` 的 Nav2 应提供：

```text
/robot_1/navigate_to_pose    nav2_msgs/action/NavigateToPose
/robot_1/follow_path         nav2_msgs/action/FollowPath
```

检查：

```bash
ros2 action list -t
ros2 lifecycle nodes
```

如现有单机器人 Nav2 没有命名空间，可在 launch 中用 `namespace:=''`，但 `robot_id` 仍要与计划一致。命名空间只改变节点/Topic/Action 名称，不会自动修复 TF frame；需要已存在且一致的 `map → odom → base_link` 链，或你自己的带机器人前缀的 frame 配置。

本包 `maps/farm_map.yaml` + PGM 是由田块多边形和演示通道生成的**合成占用地图**，不是现场 SLAM 地图。它的原点与分辨率见 `MAP_PROVENANCE.md`。在 Nav2 中加载地图只是输入地图，并不能提供机器人定位。原始经纬度已经转换成本项目的局部米制坐标；不要给现有 SLAM 地图直接塞入这些数值，必须先完成坐标对齐。

### 6.2 启动一个机器人执行器

```bash
ros2 launch farm_carrier_bridge mission.launch.py namespace:=robot_1 robot_id:=robot_1 plan:=/absolute/path/to/plan_robot_1.json use_sim_time:=true mock_handshakes:=false
```

Gazebo 使用 `use_sim_time:=true`，真机通常用 `false`。Action 的执行和取消 watchdog 使用**墙钟**：即使仿真时钟暂停，超时仍会触发，避免无限等待。可根据路段长度调整 `action_timeout_s:=900.0`。

节点启动后等待 `WAIT_DEPLOY_CONFIRM`。完成实际/已有仿真的卸载、离车、定位和执行许可后，由操作者或独立装卸控制器调用：

```bash
ros2 service call /robot_1/farm_mission_executor/confirm_deployment std_srvs/srv/Trigger '{}'
```

这是外部确认信号，不是装卸设备指令。无实际机构的演示可显式设 `mock_handshakes:=true`；日志会标为 `MOCK_HANDSHAKE`。

所有导航任务完成后会进入 `WAIT_RECOVERY_CONFIRM`。如果计划没有 `return` 段，机器人仍在最后任务终点；运行器不会假装已返回母车。先完成集合/对接/装载，再调用独立的回收确认服务：

```bash
ros2 service call /robot_1/farm_mission_executor/confirm_recovery std_srvs/srv/Trigger '{}'
```

两个确认接口分开，避免迟到的部署确认被误当成回收确认。`COMPLETED` 在真实模式下依赖外部确认，而不是通过经过某个坐标推断已装车。

第二个机器人使用另一个终端、另一个命名空间和自己的文件。仅靠命名空间不能防止机器人碰撞；实际多机器人调度、通道互斥、相互感知和交通管理必须由你现有系统或后续模块实现。

### 6.3 观察、取消和处理失败

```bash
ros2 topic echo /robot_1/farm_mission_executor/status
ros2 service call /robot_1/farm_mission_executor/cancel_mission std_srvs/srv/Trigger '{}'
```

默认反馈目录 `/tmp/farm_feedback`：

```text
robot_1_status.json
robot_1_events.jsonl
```

通过 `output_dir:=/absolute/path/to/feedback` 改为持久目录。文件明确标识 `source: ros2_executor`，不覆盖 Java `/api/state`，也不向 Java 仿真引擎提交假想位姿。

`goal_id` 是每个 Action 的 UUID，用于排除过时回调。必须同时满足 ROS Action `SUCCEEDED` 和 Nav2 结果无错误，才会推进任务。拒绝、取消、abort 和超时都会停止自动推进。即使请求取消后收到迟到的 `SUCCEEDED`，也不会因此开始下一段。

取消请求返回不代表车辆已停。节点继续等待终止结果；若超时进入 `MOTION_UNCONFIRMED`，不再发送后续目标，必须由外部系统确认停机。进程被强制杀死或通信断开时，软件不能承诺底盘已经停止；实际底盘需具备独立看门狗与急停。

可选订阅相对 Topic `battery_state`（`sensor_msgs/BatteryState`）。有效 `percentage` 是 0–1；低于默认 0.15 会取消任务并等待外部处理。未收到电池数据不意味着电量充足。它不是自动补能闭环，更不操作充电器；Java 仿真的补能规则与物料模型不会直接改变真机电量。

## 7. 后续把固定执行升级为真实系统闭环

现在可以复用：状态、任务/资源约束、覆盖条带、接口契约、动作终止规则与日志。要进一步做真实闭环，需要增加：

1. 车队调度服务拥有实际任务分配与版本号；重新分配须取消旧目标并获得确认。
2. 真实母车状态、机器人定位、能量和载荷反馈；使用实际时间戳和过期检测。
3. 卸载、装载、对接和充电的独立 Action Server；确认信号来自执行器/传感器，而非模拟计时。
4. 通道与站点占用管理，多机器人冲突处理和故障救援。
5. 将状态、任务和执行日志关联，重启时恢复剩余任务；不能把 Java 的已完成状态当真机记录。
6. 在 Gazebo 中做闭环验收，再进入实际设备测试；故障、定位丢失、通信中断、取消失败均需验收。

这些是后续接口实现范围，不是本交付包已经通过实机验证的能力。

## 8. 官方接口参考

- AnyLogic Agent 建模与 Java 类型：https://anylogic.help/online/anylogic/agentbased/agent.html
- ROS 2 Python ActionClient API：https://docs.ros.org/en/jazzy/p/rclpy/rclpy.action.client.html
- Nav2 Jazzy FollowPath Action：https://api.nav2.org/actions/jazzy/followpath.html
- Nav2 Jazzy BasicNavigator 参考（本包使用低层异步 ActionClient，便于明确控制 UUID、取消与结果）：https://api.nav2.org/nav2-jazzy/html/classnav2__simple__commander_1_1robot__navigator_1_1BasicNavigator.html

官方 API 说明不替代你的本地版本验证。安装后应以 `ros2 interface show nav2_msgs/action/FollowPath` 和实际运行结果为准。
