# Farm Carrier System

Start with [README_ZH.md](README_ZH.md), the complete Chinese user and engineering guide.

Run the included Java 8+ executable:

```bash
java -jar farm-carrier.jar
```

Open http://127.0.0.1:8765. Keep `maps/` and `ui/` beside the JAR.

The package implements a deterministic multi-agent **simulation** of carrier transport, worker deployment, field coverage, resource-aware service, recovery and return. It reuses the uploaded project's real Feld 13 polygon and entrances, with explicitly synthetic near-field infrastructure. Java sources, a local web dashboard, maps, scenarios, exports, tests, AnyLogic integration and a ROS 2 Jazzy path executor are included.

This is not an exported native AnyLogic `.alp` model or a verified physical robot control stack. ROS 2 and AnyLogic vendor runtime validation remain external integration steps. See `docs/INTEGRATION_GUIDE.md` and `docs/VALIDATION_REPORT.md` for exact boundaries.

Build from source using JDK 17+: `java tools/Build.java`.

