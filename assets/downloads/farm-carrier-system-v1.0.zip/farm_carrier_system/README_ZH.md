# 农业运载车与田间机器人协同作业系统

**版本 1.0 · Java 多 Agent 仿真工程 · 含真实田块地图、监控界面、AnyLogic 与 ROS 2 接入组件。**

这个项目把“母车送机器人到田间 → 卸载部署 → 自主作业 → 按需补给 → 断点续作 → 回收装载 → 集体返程”做成了可运行闭环。主程序已编译为 `farm-carrier.jar`，不需要先配置原项目的 Maven、数据库或 AnyLogic 环境。

**交付范围：完整可运行的任务与运动学仿真。** 地面机器人、装卸与充电采用明确的仿真模型；原生 AnyLogic `.alp` 模型、Gazebo 全套底盘、物理装卸机构和真实车队闭环不在已验证范围内。包内有可编译的 AnyLogic 接入类和 ROS 2 导航执行器，具体接入步骤见文档。

## 1. 三分钟启动

### Windows

1. 将整个压缩包解压到一个目录，如 `D:\projects\farm_carrier_system`。不要只取出 JAR。
2. 在终端执行 `java -version`。主程序需要 Java 8 或更高版本；若还没有 Java，安装带 Java 运行环境的 JDK 17 即可同时运行和重新构建。
3. 双击 `start.bat`，或在 PowerShell 中执行：

```powershell
cd D:\projects\farm_carrier_system
.\start.bat
```

程序会尝试打开浏览器。未自动打开时，手动访问：

**http://127.0.0.1:8765**

选择“标准喷洒任务”、3 台机器人，点击“载入场景”，再点击“开始 / 继续”。“快进到结果”会计算到完成或需要人工恢复的状态。关闭程序使用运行窗口中的 `Ctrl+C`。

### Linux / macOS

```bash
cd /path/to/farm_carrier_system
sh start.sh
```

也可以直接：

```bash
java -jar farm-carrier.jar
```

主程序只使用 Java 自带库。查看网页不需要 Node、Python、ROS 2 或联网。当前交付是在 Linux OpenJDK 17 上构建和运行验证的；Windows / macOS 提供对应启动脚本，未在这些操作系统上实测。

## 2. 可以演示什么

| 场景 | 行为与观察重点 |
|---|---|
| 标准喷洒 `normal` | 母车送达、依次卸载；动态领取条带；机器人低电/缺料返航补给；完成后装车返库 |
| 低电量 `low_battery` | 机器人 1 初始电量为额定值的 30%；根据往返能耗预检与作业检查决定服务 |
| 收获 `harvest` | 作业过程中产生模拟作物重量；货箱将满时返航卸货；作物转移到母车，最后随车运回 |
| 返程阻塞 `blocked_return` | 第一次返航时注入阻塞，进入 `WAITING_RECOVERY`；点击“解除阻塞”后才能继续 |
| 设备故障 `robot_fault` | 开始作业后注入设备故障；按日志选择故障机器人，点击“确认修复”后才能继续 |
| 静态基线 `baseline` | 按条带序号固定分配任务，用于与动态分配做同参数对比 |

运行中可随时“召回全队”。提前召回的最终状态是 `CANCELLED`，界面显示“召回已完成”；即使全部机器人已经回车，也不会把未完成的覆盖标成作业完成。故障、阻路和操作者暂停是不同条件；解除阻路不会顺带清除设备故障。

网页包括真实田界、规划条带、实际任务归属、运动轨迹、母车与机器人状态、电量/载荷、补给队列、任务流程、事件记录，以及路径/结果导出。地图支持放大、缩小、平移和全图恢复。

## 3. 地图确实来自原项目

本包选择上传工程中的：

```text
verfahrenssimulation/farms/farms_EkoTech/E4A_Kleiner Modellbetrieb_Feld13_NurDrohne.json
```

保留 **Feld 13 的四个原始顶点、三个原始入口和 Hof1 农场位置**。田块换算面积约 **123,875.726 m²，即 12.3876 ha**。原数据的坐标顺序是 `[纬度, 经度]`，GeoJSON 改为 `[经度, 纬度]`，运行地图为以第一入口为原点的局部米坐标，X 向东、Y 向北。

原 Hof1 到这个入口约 1.731 km；原场景没有足够信息证明某条道路真实可行。因此默认演示采用近田基地和连接道路，原 Hof1 仍保留在地图资料中，但不作为默认运输起点。田块完整保留原大小，没有缩成示意矩形。

| 文件 | 用途 |
|---|---|
| `maps/original_fields.geojson` | 原田界、入口与 Hof 的地理坐标 |
| `maps/farm_map.json` | Java 运行地图，局部米制；含合成的基地、停靠点、道路和入口通道 |
| `maps/farm_map.pgm` + `farm_map.yaml` | 从田界与演示通道生成的占用掩膜，后续可接 map_server；**不是 SLAM 实测图** |
| `maps/source_field13_excerpt.json` | 随包提供的最小原始字段摘录，可独立重建地图 |
| `maps/map_preview.png` / `.svg` | 地图预览 |
| `maps/source_summary.json` | 来源哈希、坐标假设、面积与连通性结果 |

PGM 分辨率为 1 m，尺寸 545 × 447，原点 `[-75,-397]`。它没有做机器人轮廓膨胀；真实 Nav2 footprint、定位和地图对齐需要单独配置。空障碍列表只说明原场景没有给障碍，不代表现场没有沟渠、树木或其他车辆。

地图来源、重建公式与验证见 [MAP_PROVENANCE.md](docs/MAP_PROVENANCE.md)。重建所有文本地图与 PGM 仅需 Python 标准库：

```bash
python tools/import_original_map.py
```

## 4. 无界面批量运行、结果与参数

运行一组可重复的标准任务：

```bash
java -jar farm-carrier.jar --headless --scenario normal --robots 3 --output runs/normal
```

输出包括 `metrics.json`、`snapshot.json`、`events.json`、`events.csv`、`mission_plan.json` 和每台机器人的 `plan_robot_*.json`。网页“保存本次运行记录”写到固定目录 `runs/dashboard`，再次保存会更新该目录。

更换场景：

```bash
java -jar farm-carrier.jar --headless --scenario harvest --output runs/harvest
java -jar farm-carrier.jar --headless --scenario baseline --output runs/baseline
```

故障场景的无界面运行会停在需要恢复的状态，不会自动清故障。CLI 返回码：`0` 正常完成、`2` 达到时间上限、`3` 等待恢复、`4` 失败、`5` 提前召回完成。对应日志始终写入输出目录。

完整参数模板为 `config/simulation.example.json`，复制修改后执行：

```bash
java -jar farm-carrier.jar --parameters config/simulation.example.json
```

或同时使用 `--headless`。其他选项：`--map maps/farm_map.json`、`--port 8766`、`--no-browser`、`--dt 0.5`、`--max-seconds 86400`。`--dt` 仅用于批量运行；引擎会把时间推进细分到最多 0.25 秒。图形模式支持 1–300 倍播放速度，改变播放速度不会改变模型物理时间的定义。

模板中的电池、功率、速度、物料和作物参数是**演示假设**；9 m 幅宽取自原无人机场景配置，也不等于你的地面机器人真实机具宽度。修改为实机参数后应重新验收，不能直接沿用示例性能数据。

## 5. 源码结构与学习顺序

| 路径 | 内容 |
|---|---|
| `src/main/java/farm/sim/MissionEngine.java` | Agent 状态、任务调度、补给与回收、故障/召回、资源约束 |
| `src/main/java/farm/sim/Geometry.java` | 简单多边形、扫描线条带、凹田连接、道路图寻路 |
| `src/main/java/farm/sim/App.java` | 命令行、仅本机监听的 HTTP 服务、导出 |
| `src/main/java/farm/sim/Json.java` | 无外部依赖的 JSON 编解码 |
| `src/main/java/farm/sim/CoreTests.java` | 20 项有行为意义的回归验证 |
| `ui/` | 中文实时监控网页 |
| `integrations/anylogic/` | 可导入 AnyLogic 的 Java facade、周期事件与图形绑定示例 |
| `integrations/ros2/` | ROS 2 Jazzy `ament_python` 导航执行器、计划契约、测试 |
| `reports/` | 实际验证记录、性能对比、浏览器截图 |
| `tools/` | 构建、验证、地图重建工具 |

先看 [REQUIREMENTS_AND_INTEGRATION.md](docs/REQUIREMENTS_AND_INTEGRATION.md) 理解需求映射与项目结合方案，再看 [DECISION_AND_STATE_MACHINES.md](docs/DECISION_AND_STATE_MACHINES.md)，最后沿 `tick → step → updateRobot → requestReturn → updateBay` 阅读代码。

## 6. 构建与验证

**运行已有 JAR 无需构建。** 修改 Java 源码后，用 JDK 17 或更高版本执行：

```bash
java tools/Build.java
```

也可以使用 `build.bat` / `sh build.sh`。构建会将源码编译为 Java 8 字节码，输出根目录 JAR，包括 `farm.anylogic.AnyLogicMissionBridge`。它不下载 Maven 依赖。

只验证 Java 核心：

```bash
java -Xmx512m -cp farm-carrier.jar farm.sim.CoreTests maps/farm_map.json
```

有 Python 3.9+ 时，一次复现核心、Java facade、Python 契约、跨语言计划读取和六场景批量运行：

```bash
python tools/verify.py
```

先启动网页服务，然后可选执行本地 HTTP 接口验收：

```bash
python tools/http_smoke.py
```

浏览器验收脚本 `tools/browser_smoke.cjs` 是可选开发工具，需要 Node、Playwright 和可用浏览器；普通用户运行本系统完全不需要这些工具。交付时已用实际 Chromium 浏览器检查页面交互与 1440 / 1024 / 390 像素布局，报告见 `reports/browser-tests.json`。

## 7. 怎样接入你已有的机器人项目

这个系统适合放在你已有 CCPP 与 ROS 2 导航项目的上层：

- **本项目**决定任务归属、母车停靠、部署时机、补给需求、回收和任务结束条件。
- **你的 CCPP 项目**负责复杂田界、障碍、幅宽和转弯约束下的覆盖轨迹。
- **ROS 2 / Nav2**执行到点导航与覆盖路径，回传成功、失败、取消、实际位置与电量。
- **后续装卸/充电控制器**确认机器人是否真正下车、对接、装车锁定和充电完成。

包内 ROS 执行器读取冻结的 `transit / coverage / return` 计划；覆盖段先接近起点，再使用 `FollowPath`。它具有 UUID 结果隔离、取消与超时、独立部署/回收确认接口和反馈记录。**它还不是驱动真实母车、自动机械装卸和动态补能的全车队控制器。**

AnyLogic 可导入本包 JAR、在 Main 中创建 facade、由一个周期事件推进引擎，并用 getter 更新显示 Agent。原工程没有 `.alp/.alpx` 模型，因此本包提供接入代码和操作说明，没有声称交付了已经在 AnyLogic 中打开过的原生模型文件。

完整安装与命令见 [INTEGRATION_GUIDE.md](docs/INTEGRATION_GUIDE.md)。在实机接入前先统一 `map` 坐标、namespace / TF、机器人 footprint 和机具幅宽。Java 仿真状态与 ROS 实际执行状态各自独立，不能互相冒充。

## 8. 已验证与仍需验证

已验证 Java 闭环、异常恢复、地图几何、资源守恒、真实 HTTP 接口、浏览器交互以及 Java/Python 计划契约。详细数据见 [VALIDATION_REPORT.md](docs/VALIDATION_REPORT.md)。

当前不包含三维飞行动力学、田内多机器人连续避碰、轮胎/土壤/坡度、转弯半径、真实定位误差、机械装卸设计和实际充电器控制。覆盖完成率是**已完成条带中心线长度 / 计划条带中心线长度**；不是机具足迹并集计算出来的实测无漏耕率。

等待设备修复或道路解锁时，整个仿真时间冻结。这便于检查状态机，但现场维修时间不会计入该演示的任务时间；故障恢复后的耗时不能用来证明真实系统的可用率。

## 9. 常见问题

**双击 JAR 没反应：** 用终端执行 `java -jar farm-carrier.jar` 看错误；确保完整解压，`maps/` 和 `ui/` 与 JAR 同目录。

**端口被占用：** 执行 `java -jar farm-carrier.jar --port 8766`，访问 `http://127.0.0.1:8766`。

**页面显示“等待人工恢复”：** 查看事件和故障机器人的状态；分别解除阻路或确认相应机器人修复，然后开始/继续。按“快进”也不会越过未解除的故障。

**地图换成有障碍的田块后拒绝启动：** 当前内置规划器不处理障碍，程序明确拒绝非空 `obstacles`。应接入你已有的障碍感知 CCPP 规划器，并扩充路径有效性检查。

**运行器报容量不可行：** 电池必须满足到作业点再返回的最低能量；料箱/货箱也需要满足预测窗口内的最低工作量。引擎会拒绝明知不可能完成而持续补给的参数，防止零进度活锁。

**Linux 浏览器中文显示方框：** 该系统使用本地字体；安装本机可用的中文字体即可。字体缺失不影响后台计算。Windows 的微软雅黑和 macOS 的中文系统字体通常能直接显示。

