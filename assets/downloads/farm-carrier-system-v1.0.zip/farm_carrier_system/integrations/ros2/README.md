# ROS 2 bridge

See `../../docs/INTEGRATION_GUIDE.md` for complete Chinese setup and scope.

- `farm_carrier_bridge/`: ament_python package for ROS 2 Jazzy / Nav2.
- `examples/plan_robot_1.json`: small synthetic route example, not a measured robot mission.
- Pure Python validation: from `farm_carrier_bridge/`, run `python -m unittest discover -s test -v`.
- ROS runtime was unavailable during packaging; no Gazebo, Nav2 or physical robot end-to-end verification is claimed.
- Frozen plan execution only. External deployment/recovery confirmation defaults to required.
