import copy
import math
import unittest
from farm_carrier_bridge.contract import normalize_plan, tasks_for_plan, GoalGuard


class ContractTests(unittest.TestCase):
    def setUp(self):
        self.raw = {'schema_version': 1, 'robot_id': 'robot_1', 'frame_id': 'map',
                    'segments': [{'segment_id': 'a', 'kind': 'coverage', 'points': [[0, 0], [2, 0]]},
                                 {'segment_id': 'b', 'kind': 'coverage', 'points': [[2, 2], [0, 2]]}]}

    def test_separate_strips_have_navigation_connectors(self):
        tasks = tasks_for_plan(normalize_plan(self.raw))
        self.assertEqual([x['mode'] for x in tasks], ['navigate_to_pose', 'follow_path'] * 2)
        self.assertEqual(tasks[2]['points'], [[2.0, 2.0]])

    def test_fleet_selection(self):
        fleet = {'robots': [self.raw], 'units': {'distance': 'm'}}
        self.assertEqual(normalize_plan(fleet, 'robot_1')['robot_id'], 'robot_1')
        with self.assertRaises(ValueError):
            normalize_plan(fleet)
        with self.assertRaises(ValueError):
            normalize_plan(fleet, 'robot_2')

    def test_nonfinite_and_duplicate_rejected(self):
        for invalid in (math.nan, math.inf, True, '4'):
            raw = copy.deepcopy(self.raw)
            raw['segments'][0]['points'][0][0] = invalid
            with self.assertRaises(ValueError):
                normalize_plan(raw)
        raw = copy.deepcopy(self.raw)
        raw['segments'][1]['segment_id'] = 'a'
        with self.assertRaises(ValueError):
            normalize_plan(raw)

    def test_simulation_status_never_certifies_physical_work(self):
        self.raw['segments'][0]['status'] = 'COMPLETED'
        self.assertEqual(len(normalize_plan(self.raw)['segments']), 2)

    def test_failed_and_canceled_results_never_advance(self):
        guard = GoalGuard()
        for status in (2, 5, 6):
            token = guard.start()
            self.assertNotEqual(guard.finish(token, status), 'SUCCEEDED')
        token = guard.start()
        self.assertEqual(guard.finish(token, 4, 2), 'FAILED')

    def test_success_after_cancel_is_not_completion(self):
        guard = GoalGuard()
        token = guard.start()
        guard.cancel()
        self.assertEqual(guard.finish(token, 4), 'CANCELED')

    def test_obsolete_result_does_not_finish_new_goal(self):
        guard = GoalGuard()
        old = guard.start()
        self.assertEqual(guard.finish(old, 4), 'SUCCEEDED')
        new = guard.start()
        self.assertEqual(guard.finish(old, 4), 'STALE')
        self.assertTrue(guard.matches(new))
        self.assertEqual(guard.finish(new, 4), 'SUCCEEDED')

    def test_overlapping_dispatch_is_rejected(self):
        guard = GoalGuard()
        guard.start()
        with self.assertRaises(RuntimeError):
            guard.start()


if __name__ == '__main__':
    unittest.main()
