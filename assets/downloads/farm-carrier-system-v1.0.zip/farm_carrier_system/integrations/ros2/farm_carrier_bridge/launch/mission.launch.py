from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue


def generate_launch_description():
    return LaunchDescription([
        DeclareLaunchArgument('namespace', default_value='robot_1'),
        DeclareLaunchArgument('robot_id', default_value='robot_1'),
        DeclareLaunchArgument('plan', description='Absolute path to a single-robot or fleet export JSON'),
        DeclareLaunchArgument('use_sim_time', default_value='false'),
        DeclareLaunchArgument('mock_handshakes', default_value='false'),
        DeclareLaunchArgument('output_dir', default_value='/tmp/farm_feedback'),
        DeclareLaunchArgument('action_timeout_s', default_value='900.0'),
        Node(package='farm_carrier_bridge', executable='mission_executor', output='screen',
             namespace=LaunchConfiguration('namespace'),
             parameters=[{'plan_file': LaunchConfiguration('plan'),
                          'robot_id': LaunchConfiguration('robot_id'),
                          'use_sim_time': ParameterValue(LaunchConfiguration('use_sim_time'), value_type=bool),
                          'mock_handshakes': ParameterValue(LaunchConfiguration('mock_handshakes'), value_type=bool),
                          'output_dir': LaunchConfiguration('output_dir'),
                          'action_timeout_s': ParameterValue(LaunchConfiguration('action_timeout_s'), value_type=float)}])
    ])
