from setuptools import setup
from glob import glob

package_name = 'farm_carrier_bridge'
setup(name=package_name, version='0.1.0', packages=[package_name],
      data_files=[('share/ament_index/resource_index/packages', ['resource/' + package_name]),
                  ('share/' + package_name, ['package.xml']),
                  ('share/' + package_name + '/launch', glob('launch/*.launch.py'))],
      install_requires=['setuptools'], zip_safe=True,
      maintainer='Farm Carrier Demo', maintainer_email='maintainer@example.invalid',
      description='Frozen farm mission plans to namespaced Nav2 actions; external recovery confirmation.',
      license='MIT',
      entry_points={'console_scripts': ['mission_executor = farm_carrier_bridge.mission_executor:main',
                                       'validate_plan = farm_carrier_bridge.contract:main']})
