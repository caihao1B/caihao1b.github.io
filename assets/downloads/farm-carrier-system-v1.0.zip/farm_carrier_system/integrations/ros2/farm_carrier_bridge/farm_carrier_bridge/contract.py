"""Offline-testable immutable plan contract and action completion guard (no ROS imports)."""
import json
import math
import re
import uuid
from pathlib import Path


def _point(value):
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError('points must contain exactly [x, y] in local metres')
    if any(isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) for v in value):
        raise ValueError('coordinates must be finite numbers')
    return [float(value[0]), float(value[1])]


def normalize_plan(data, robot_id=None):
    """Accept one robot file or the engine export with a robots list.

    Snapshot status is metadata only: it never certifies physical completion.
    Explicitly freeze/export a remaining-task plan if resuming a real mission.
    """
    if not isinstance(data, dict):
        raise ValueError('plan must be a JSON object')
    if data.get('schema_version', 1) != 1:
        raise ValueError('unsupported schema_version')
    frame = data.get('frame_id', 'map')
    if not isinstance(frame, str) or not frame.strip() or frame.startswith('/'):
        raise ValueError('frame_id must be a nonempty TF frame without leading slash')
    units = data.get('units', {})
    if units is not None and not isinstance(units, dict):
        raise ValueError('units must be an object')
    if units and units.get('distance', 'm') != 'm':
        raise ValueError('plan coordinates must be in metres')
    source = data
    if 'robots' in data:
        if not robot_id:
            raise ValueError('robot_id is required for a fleet export')
        candidates = [r for r in data['robots'] if r.get('robot_id') == robot_id]
        if len(candidates) != 1:
            raise ValueError('robot_id must match exactly one robot in fleet export')
        source = candidates[0]
    frame = source.get('frame_id', frame)
    if not isinstance(frame, str) or not frame.strip() or frame.startswith('/'):
        raise ValueError('robot frame_id must be a nonempty TF frame without leading slash')
    rid = source.get('robot_id')
    if not isinstance(rid, str) or not re.fullmatch(r'[A-Za-z][A-Za-z0-9_]*', rid):
        raise ValueError('robot_id must be a simple identifier, e.g. robot_1')
    if robot_id and rid != robot_id:
        raise ValueError('requested robot_id differs from plan robot_id')
    segments = source.get('segments')
    if not isinstance(segments, list) or not segments:
        raise ValueError('plan requires at least one segment')
    out = []
    seen = set()
    for segment in segments:
        sid = segment.get('segment_id')
        if not isinstance(sid, str) or not sid or sid in seen:
            raise ValueError('segment_id must be nonempty and unique')
        seen.add(sid)
        kind = segment.get('kind', 'coverage')
        if kind not in ('coverage', 'transit', 'return'):
            raise ValueError('kind must be coverage, transit, or return')
        points = [_point(p) for p in segment.get('points', [])]
        if not points or (kind == 'coverage' and len(points) < 2):
            raise ValueError('coverage requires at least two points; other segments require one')
        if kind == 'coverage' and not any(p != points[0] for p in points[1:]):
            raise ValueError('coverage path must have nonzero length')
        out.append({'segment_id': sid, 'kind': kind, 'points': points,
                    'field_id': segment.get('field_id')})
    return {'schema_version': 1, 'frame_id': frame,
            'robot_id': rid, 'segments': out, 'origin_wgs84': data.get('origin_wgs84'),
            'assignment': data.get('assignment', 'frozen_plan')}


def load_plan(path, robot_id=None):
    return normalize_plan(json.loads(Path(path).read_text(encoding='utf-8')), robot_id)


def tasks_for_plan(plan):
    """Navigate to each coverage start first; then follow that coverage path.

    Separate strips never create an unplanned straight line across headlands.
    Transit/return waypoints are routed individually through NavigateToPose.
    These connectors need a configured Nav2 global costmap/planner.
    """
    tasks = []
    for segment in plan['segments']:
        base = {'segment_id': segment['segment_id'], 'kind': segment['kind']}
        if segment['kind'] == 'coverage':
            tasks.append(dict(base, task_id=segment['segment_id'] + ':approach',
                              mode='navigate_to_pose', points=[segment['points'][0]]))
            tasks.append(dict(base, task_id=segment['segment_id'] + ':cover',
                              mode='follow_path', points=segment['points']))
        else:
            for i, point in enumerate(segment['points']):
                tasks.append(dict(base, task_id=segment['segment_id'] + ':' + str(i),
                                  mode='navigate_to_pose', points=[point]))
    return tasks


class GoalGuard:
    """Prevent obsolete callbacks, aborted/canceled goals, and error results advancing a mission."""
    def __init__(self):
        self.goal_id = None
        self.cancel_requested = False
        self.active = False

    def start(self):
        if self.active:
            raise RuntimeError('cannot overlap mission goals')
        self.goal_id = uuid.uuid4().hex
        self.cancel_requested = False
        self.active = True
        return self.goal_id

    def matches(self, goal_id):
        return self.active and self.goal_id == goal_id

    def cancel(self):
        if self.active:
            self.cancel_requested = True

    def finish(self, goal_id, status, error_code=0):
        if not self.matches(goal_id):
            return 'STALE'
        self.active = False
        if self.cancel_requested:
            return 'CANCELED'  # late SUCCESS after cancel still must not advance mission
        if status == 4 and error_code == 0:  # action_msgs/GoalStatus.STATUS_SUCCEEDED
            return 'SUCCEEDED'
        if status == 5:
            return 'CANCELED'
        return 'FAILED'


def main():
    import argparse
    parser = argparse.ArgumentParser(description='Validate/freeze a Java export; no ROS required')
    parser.add_argument('plan')
    parser.add_argument('--robot-id')
    parser.add_argument('--output', help='Write normalized single-robot plan')
    args = parser.parse_args()
    plan = load_plan(args.plan, args.robot_id)
    if args.output:
        Path(args.output).write_text(json.dumps(plan, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'valid': True, 'robot_id': plan['robot_id'],
                      'segments': len(plan['segments']), 'nav2_goals': len(tasks_for_plan(plan))}, indent=2))


if __name__ == '__main__':
    main()
