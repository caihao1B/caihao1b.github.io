"""ROS 2 Jazzy action executor for a FROZEN plan, independent of Java simulation.

Uses asynchronous ActionClient callbacks; never advances on cancel/abort/timeout.
Loading/unloading are external confirmation gates, not physical docking drivers.
"""
import json
import math
import os
import time
from pathlib import Path

import rclpy
from rclpy.action import ActionClient
from rclpy.node import Node
from rclpy.clock import Clock, ClockType
from nav2_msgs.action import FollowPath, NavigateToPose
from nav_msgs.msg import Path as RosPath
from geometry_msgs.msg import PoseStamped
from sensor_msgs.msg import BatteryState
from std_msgs.msg import String
from std_srvs.srv import Trigger
from unique_identifier_msgs.msg import UUID

from .contract import GoalGuard, load_plan, tasks_for_plan


class MissionExecutor(Node):
    def __init__(self):
        super().__init__('farm_mission_executor')
        defaults = {'plan_file': '', 'robot_id': 'robot_1', 'output_dir': '/tmp/farm_feedback',
                    'mock_handshakes': False, 'action_timeout_s': 900.0,
                    'server_wait_timeout_s': 30.0, 'cancel_timeout_s': 10.0,
                    'controller_id': '', 'goal_checker_id': '', 'progress_checker_id': '',
                    'low_battery_fraction': 0.15, 'path_spacing_m': 0.25}
        for key, value in defaults.items():
            self.declare_parameter(key, value)
        self.cfg = {k: self.get_parameter(k).value for k in defaults}
        for key in ('action_timeout_s', 'server_wait_timeout_s', 'cancel_timeout_s', 'path_spacing_m'):
            if not math.isfinite(self.cfg[key]) or self.cfg[key] <= 0:
                raise ValueError(key + ' must be positive and finite')
        self.plan = load_plan(self.cfg['plan_file'], self.cfg['robot_id'])
        self.tasks = tasks_for_plan(self.plan)
        self.index = 0
        self.state = 'WAIT_DEPLOY_CONFIRM'
        self.reason = 'Confirm physical unloading, safe separation and localization before navigation.'
        self.guard = GoalGuard()
        self.handle = None
        self.current_task = None
        self.started_at = 0.0
        self.cancel_started_at = 0.0
        self.wait_started_at = time.monotonic()
        self.last_feedback_at = 0.0
        self.feedback = {}
        self.stop_reason = ''
        self.output = Path(self.cfg['output_dir']).expanduser()
        self.output.mkdir(parents=True, exist_ok=True)
        self.status_file = self.output / (self.plan['robot_id'] + '_status.json')
        self.events_file = self.output / (self.plan['robot_id'] + '_events.jsonl')
        self.status_pub = self.create_publisher(String, '~/status', 10)
        self.deploy_service = self.create_service(Trigger, '~/confirm_deployment', self.confirm_deployment)
        self.recover_service = self.create_service(Trigger, '~/confirm_recovery', self.confirm_recovery)
        self.cancel_service = self.create_service(Trigger, '~/cancel_mission', self.cancel_service_callback)
        self.battery_sub = self.create_subscription(BatteryState, 'battery_state', self.on_battery, 10)
        self.clients = {'navigate_to_pose': ActionClient(self, NavigateToPose, 'navigate_to_pose'),
                        'follow_path': ActionClient(self, FollowPath, 'follow_path')}
        self.wall_clock = Clock(clock_type=ClockType.STEADY_TIME)
        self.timer = self.create_timer(0.2, self.step, clock=self.wall_clock)
        self.log_event('mission_loaded', {'mock_handshakes': self.cfg['mock_handshakes'],
                                        'plan_assignment': self.plan.get('assignment')})
        self.get_logger().info('Loaded %d tasks. No physical loading/unloading actuator is provided.' % len(self.tasks))
        self.write_status()

    def log_event(self, event, details=None):
        data = {'wall_time_unix': time.time(), 'robot_id': self.plan['robot_id'],
                'event': event, 'state': self.state, 'goal_id': self.guard.goal_id,
                'task_index': self.index, 'details': details or {}}
        with self.events_file.open('a', encoding='utf-8') as handle:
            handle.write(json.dumps(data, ensure_ascii=False, allow_nan=False) + '\n')

    def write_status(self):
        data = {'schema_version': 1, 'source': 'ros2_executor', 'robot_id': self.plan['robot_id'],
                'wall_time_unix': time.time(), 'namespace': self.get_namespace(),
                'state': self.state, 'reason': self.reason, 'goal_id': self.guard.goal_id,
                'task_index': self.index, 'task_count': len(self.tasks),
                'task': self.current_task, 'feedback': self.feedback,
                'mock_handshakes': self.cfg['mock_handshakes']}
        text = json.dumps(data, ensure_ascii=False, allow_nan=False, indent=2)
        temporary = self.status_file.with_suffix('.json.tmp')
        temporary.write_text(text, encoding='utf-8')
        os.replace(str(temporary), str(self.status_file))
        if rclpy.ok():
            self.status_pub.publish(String(data=text))

    def change_state(self, state, reason):
        self.state, self.reason = state, reason
        self.log_event('state_changed', {'reason': reason})
        self.write_status()

    def confirm_deployment(self, request, response):
        if self.state != 'WAIT_DEPLOY_CONFIRM':
            response.success, response.message = False, 'Deployment is not pending: ' + self.state
            return response
        return self.confirm_handshake(request, response)

    def confirm_recovery(self, request, response):
        if self.state != 'WAIT_RECOVERY_CONFIRM':
            response.success, response.message = False, 'Recovery is not pending: ' + self.state
            return response
        return self.confirm_handshake(request, response)

    def confirm_handshake(self, request, response):
        del request
        if self.state == 'WAIT_DEPLOY_CONFIRM':
            self.wait_started_at = time.monotonic()
            self.change_state('READY', 'Deployment confirmed by external caller.')
            response.success, response.message = True, 'Deployment confirmed; navigation may start.'
        elif self.state == 'WAIT_RECOVERY_CONFIRM':
            self.change_state('COMPLETED', 'Recovery confirmed by external caller.')
            response.success, response.message = True, 'Recovery confirmed; mission complete.'
        else:
            response.success, response.message = False, 'No handshake pending: ' + self.state
        return response

    def cancel_service_callback(self, request, response):
        del request
        self.request_cancel('operator_requested_cancel')
        response.success = True
        response.message = 'Cancellation requested. Check status; this is not a stop acknowledgement.'
        return response

    def on_battery(self, msg):
        level = float(msg.percentage)
        if math.isfinite(level) and 0.0 <= level <= 1.0:
            if level <= self.cfg['low_battery_fraction'] and self.state in ('READY', 'RUNNING'):
                self.request_cancel('low_battery_requires_external_recovery')

    def step(self):
        now = time.monotonic()
        if self.cfg['mock_handshakes'] and self.state in ('WAIT_DEPLOY_CONFIRM', 'WAIT_RECOVERY_CONFIRM'):
            self.log_event('MOCK_HANDSHAKE', {'warning': 'No physical mechanism has been actuated.'})
            self.confirm_handshake(None, Trigger.Response())
        if self.state == 'READY':
            if self.index >= len(self.tasks):
                self.change_state('WAIT_RECOVERY_CONFIRM', 'Navigation done; externally recover/load the robot, then confirm.')
                return
            task = self.tasks[self.index]
            client = self.clients[task['mode']]
            if not client.server_is_ready():
                if now - self.wait_started_at > self.cfg['server_wait_timeout_s']:
                    self.change_state('FAILED', 'Nav2 action server unavailable: ' + task['mode'])
                return
            self.dispatch(task)
        elif self.state == 'RUNNING' and now - self.started_at > self.cfg['action_timeout_s']:
            self.request_cancel('action_timeout_wall_clock')
        elif self.state == 'CANCELING' and now - self.cancel_started_at > self.cfg['cancel_timeout_s']:
            self.change_state('MOTION_UNCONFIRMED', 'Cancel/result acknowledgement timed out. No further goals will be sent; operator must verify stop.')

    def pose(self, point, yaw=0.0):
        pose = PoseStamped()
        pose.header.frame_id = self.plan['frame_id']
        pose.header.stamp = self.get_clock().now().to_msg()
        pose.pose.position.x, pose.pose.position.y = point
        pose.pose.orientation.z = math.sin(yaw / 2.0)
        pose.pose.orientation.w = math.cos(yaw / 2.0)
        return pose

    def path_message(self, points):
        # Densify straight segments so local controllers receive a usable sample density.
        dense = [points[0]]
        for a, b in zip(points, points[1:]):
            steps = max(1, int(math.ceil(math.hypot(b[0]-a[0], b[1]-a[1]) / self.cfg['path_spacing_m'])))
            if len(dense) + steps > 100000:
                raise ValueError('path too large after interpolation')
            for i in range(1, steps + 1):
                dense.append([a[0] + (b[0]-a[0])*i/steps, a[1] + (b[1]-a[1])*i/steps])
        path = RosPath()
        path.header.frame_id = self.plan['frame_id']
        path.header.stamp = self.get_clock().now().to_msg()
        yaw = 0.0
        for i, point in enumerate(dense):
            if i + 1 < len(dense):
                nxt = dense[i+1]
                yaw = math.atan2(nxt[1] - point[1], nxt[0] - point[0])
            path.poses.append(self.pose(point, yaw))
        return path

    def dispatch(self, task):
        self.current_task = task
        try:
            if task['mode'] == 'follow_path':
                goal = FollowPath.Goal()
                goal.path = self.path_message(task['points'])
                goal.controller_id = self.cfg['controller_id']
                goal.goal_checker_id = self.cfg['goal_checker_id']
                if hasattr(goal, 'progress_checker_id'):
                    goal.progress_checker_id = self.cfg['progress_checker_id']
            else:
                goal = NavigateToPose.Goal()
                yaw = 0.0
                # Align at strip start when the next task is a coverage path.
                if self.index + 1 < len(self.tasks) and self.tasks[self.index+1]['mode'] == 'follow_path':
                    a, b = self.tasks[self.index+1]['points'][:2]
                    yaw = math.atan2(b[1]-a[1], b[0]-a[0])
                goal.pose = self.pose(task['points'][-1], yaw)
            token = self.guard.start()
            self.handle = None
            self.started_at = time.monotonic()
            self.change_state('RUNNING', task['task_id'])
            goal_uuid = UUID(uuid=list(bytes.fromhex(token)))
            future = self.clients[task['mode']].send_goal_async(
                goal, feedback_callback=lambda msg, t=token: self.on_feedback(t, msg), goal_uuid=goal_uuid)
            future.add_done_callback(lambda f, t=token: self.on_goal_response(t, f))
        except Exception as exc:
            # No implicit success or retry. Transport failures may leave physical motion unknown.
            self.change_state('MOTION_UNCONFIRMED' if self.guard.active else 'FAILED', 'Dispatch error: ' + str(exc))

    def on_goal_response(self, token, future):
        if not self.guard.matches(token):
            return
        try:
            handle = future.result()
            if not handle.accepted:
                self.guard.finish(token, 6)
                self.change_state('FAILED', 'Nav2 rejected goal ' + token)
                return
            self.handle = handle
            result = handle.get_result_async()
            result.add_done_callback(lambda f, t=token: self.on_result(t, f))
            self.log_event('goal_accepted')
            if self.guard.cancel_requested:
                self.send_cancel(token)
        except Exception as exc:
            self.change_state('MOTION_UNCONFIRMED', 'Goal acknowledgement error: ' + str(exc))

    def on_feedback(self, token, msg):
        if not self.guard.matches(token):
            return
        if bytes(msg.goal_id.uuid).hex() != token:
            return
        now = time.monotonic()
        if now - self.last_feedback_at < 1.0:
            return
        self.last_feedback_at = now
        data = {}
        for key in ('distance_to_goal', 'distance_remaining', 'speed', 'number_of_recoveries'):
            if hasattr(msg.feedback, key):
                value = float(getattr(msg.feedback, key))
                if math.isfinite(value):
                    data[key] = value
        self.feedback = data
        self.write_status()

    def on_result(self, token, future):
        if not self.guard.matches(token):
            return
        try:
            wrapped = future.result()
            code = int(getattr(wrapped.result, 'error_code', 0))
            outcome = self.guard.finish(token, wrapped.status, code)
            self.handle = None
            self.log_event('goal_result', {'status': wrapped.status, 'error_code': code,
                                          'error_msg': str(getattr(wrapped.result, 'error_msg', '')),
                                          'outcome': outcome})
            if outcome == 'SUCCEEDED':
                self.index += 1
                self.wait_started_at = time.monotonic()
                self.change_state('READY', 'Goal completed; next task pending.')
            elif outcome != 'STALE':
                self.change_state('FAILED', self.stop_reason or ('Action ended without success: ' + outcome))
        except Exception as exc:
            self.change_state('MOTION_UNCONFIRMED', 'Result error: ' + str(exc))

    def request_cancel(self, reason):
        if self.state in ('COMPLETED', 'FAILED') and not self.guard.active:
            return
        self.stop_reason = reason
        if not self.guard.active:
            self.change_state('FAILED', reason)
            return
        if self.guard.cancel_requested:
            return
        self.guard.cancel()
        self.cancel_started_at = time.monotonic()
        self.change_state('CANCELING', reason)
        if self.handle is not None:
            self.send_cancel(self.guard.goal_id)

    def send_cancel(self, token):
        try:
            future = self.handle.cancel_goal_async()
            future.add_done_callback(lambda f, t=token: self.on_cancel_response(t, f))
        except Exception as exc:
            self.change_state('MOTION_UNCONFIRMED', 'Cancel request failed: ' + str(exc))

    def on_cancel_response(self, token, future):
        if not self.guard.matches(token):
            return
        try:
            response = future.result()
            self.log_event('cancel_response', {'return_code': response.return_code,
                                             'goals_canceling': len(response.goals_canceling)})
            # A cancellation response is not action completion; wait for terminal result.
        except Exception as exc:
            self.change_state('MOTION_UNCONFIRMED', 'Cancel acknowledgement error: ' + str(exc))


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = MissionExecutor()
        rclpy.spin(node)
    except KeyboardInterrupt:
        if node is not None and rclpy.ok():
            node.request_cancel('executor_interrupted')
            until = time.monotonic() + 3.0
            while node.guard.active and rclpy.ok() and time.monotonic() < until:
                rclpy.spin_once(node, timeout_sec=0.1)
            if node.guard.active:
                node.change_state('MOTION_UNCONFIRMED', 'Executor shutdown before confirmed goal termination.')
    finally:
        if node is not None:
            if node.guard.active:
                node.change_state('MOTION_UNCONFIRMED', 'Process exiting before confirmed action termination; verify physical stop externally.')
            node.destroy_node()
        if rclpy.ok():
            rclpy.shutdown()


if __name__ == '__main__':
    main()
