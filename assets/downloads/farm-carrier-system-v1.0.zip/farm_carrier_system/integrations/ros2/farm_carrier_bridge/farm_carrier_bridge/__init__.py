"""Farm carrier / Nav2 integration. Simulation and physical execution are separate."""
