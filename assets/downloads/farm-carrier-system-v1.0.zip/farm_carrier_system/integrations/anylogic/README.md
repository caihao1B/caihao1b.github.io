# AnyLogic Java 8 facade

See `../../docs/INTEGRATION_GUIDE.md` for complete Chinese wiring instructions.

`farm.anylogic.AnyLogicMissionBridge` wraps `farm.sim.MissionEngine`; no vendor classes are imported.
The root `farm-carrier.jar` includes the facade. If using a separate core JAR, the supplied build scripts produce a second adapter JAR.

`snippets/` contains pasteable Main startup, cyclic event and dynamic text examples. Create the referenced AnyLogic model variables and visual Agent population before using them. A real `.alp` file is not included and the AnyLogic runtime was not available for testing.
