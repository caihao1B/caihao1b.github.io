@echo off
setlocal
if "%~1"=="" (
  echo Usage: build_bridge.bat C:\absolute\path\to\core.jar
  exit /b 2
)
set "CORE_JAR=%~f1"
set "HERE=%~dp0"
if not exist "%HERE%build\classes" mkdir "%HERE%build\classes"
javac -source 8 -target 8 -encoding UTF-8 -cp "%CORE_JAR%" -d "%HERE%build\classes" "%HERE%src\farm\anylogic\AnyLogicMissionBridge.java" "%HERE%src\farm\anylogic\BridgeSmokeTest.java"
if errorlevel 1 exit /b 1
jar cf "%HERE%build\farm-anylogic-bridge.jar" -C "%HERE%build\classes" .
if errorlevel 1 exit /b 1
echo Built %HERE%build\farm-anylogic-bridge.jar
