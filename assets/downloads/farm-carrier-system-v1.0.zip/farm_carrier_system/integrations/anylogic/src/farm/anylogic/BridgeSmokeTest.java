package farm.anylogic;

/** No AnyLogic installation required. Validates the facade against the real core. */
public final class BridgeSmokeTest {
    public static void main(String[] args) throws Exception {
        if (args.length < 2) throw new IllegalArgumentException("Usage: BridgeSmokeTest map.json output-directory [scenario]");
        String scenario = args.length > 2 ? args[2] : "normal";
        AnyLogicMissionBridge bridge = new AnyLogicMissionBridge(args[0], scenario, 3);
        if (bridge.robotIds().size() != 3) throw new AssertionError("Robot count mismatch");
        for (String robot : bridge.robotIds()) {
            if (Double.isNaN(bridge.x(robot)) || Double.isNaN(bridge.y(robot))) throw new AssertionError("Invalid pose");
            if (bridge.batteryPercent(robot) < 0.0 || bridge.batteryPercent(robot) > 100.0) throw new AssertionError("Invalid battery");
        }
        bridge.tick(0.2);
        bridge.exportPlans(args[1]);
        if (bridge.snapshotJson().length() < 10 || bridge.planJson().length() < 10) throw new AssertionError("Empty JSON");
        System.out.println("ANYLOGIC_BRIDGE_SMOKE_PASS (Java facade only; vendor runtime not tested)");
    }
}
