package farm.anylogic;

import farm.sim.Json;
import farm.sim.MissionEngine;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Java 8 facade for an AnyLogic Main agent. No vendor classes are required.
 * The bridge owns the mission engine; visual AnyLogic agents mirror snapshots.
 * Call tick from one AnyLogic cyclic event only, using seconds as the argument.
 */
public final class AnyLogicMissionBridge {
    private final MissionEngine engine;
    private Map<String, Object> snapshot;

    @SuppressWarnings("unchecked")
    public AnyLogicMissionBridge(String mapFile, String scenario, int robotCount) throws IOException {
        Object parsed = Json.parse(new String(Files.readAllBytes(Paths.get(mapFile)), StandardCharsets.UTF_8));
        if (!(parsed instanceof Map)) throw new IllegalArgumentException("Map JSON must be an object");
        engine = new MissionEngine((Map<String, Object>) parsed, scenario, robotCount);
        refresh();
    }

    /** Advance SIMULATED mission time. This is not a real robot control command. */
    public synchronized void tick(double seconds) {
        if (Double.isNaN(seconds) || Double.isInfinite(seconds) || seconds <= 0.0)
            throw new IllegalArgumentException("tick seconds must be positive and finite");
        if (!engine.isTerminal()) engine.tick(seconds);
        refresh();
    }

    public synchronized void command(String command, String robotId) {
        engine.command(command, robotId);
        refresh();
    }

    private void refresh() { snapshot = engine.snapshot(); }

    @SuppressWarnings("unchecked")
    private Map<String, Object> actor(String id) {
        if ("carrier".equals(id)) {
            Object carrier = snapshot.get("carrier");
            if (carrier instanceof Map) return (Map<String, Object>) carrier;
        }
        Object robots = snapshot.get("robots");
        if (robots instanceof List) {
            for (Object object : (List<?>) robots) {
                if (object instanceof Map) {
                    Map<String, Object> robot = (Map<String, Object>) object;
                    if (id.equals(String.valueOf(robot.get("id")))) return robot;
                }
            }
        }
        throw new IllegalArgumentException("Unknown actor: " + id);
    }

    private double number(Map<String, Object> object, String key) {
        Object value = object.get(key);
        if (!(value instanceof Number)) throw new IllegalStateException("Missing numeric field: " + key);
        return ((Number) value).doubleValue();
    }

    public synchronized double x(String actorId) { return number(actor(actorId), "x"); }
    public synchronized double y(String actorId) { return number(actor(actorId), "y"); }
    public synchronized String state(String actorId) { return String.valueOf(actor(actorId).get("state")); }
    public synchronized double batteryPercent(String actorId) { return number(actor(actorId), "battery"); }
    public synchronized double batteryKWh(String actorId) { return number(actor(actorId), "batteryKWh"); }
    public synchronized double materialKg(String robotId) { return number(actor(robotId), "materialKg"); }
    public synchronized double cargoKg(String actorId) { return number(actor(actorId), "cargoKg"); }
    public synchronized boolean isTerminal() { return engine.isTerminal(); }
    public synchronized String snapshotJson() { return Json.stringify(snapshot); }
    public synchronized String metricsJson() { return Json.stringify(engine.metrics()); }
    public synchronized String eventsJson() { return Json.stringify(engine.events()); }
    public synchronized String planJson() { return Json.stringify(engine.exportPlan()); }

    @SuppressWarnings("unchecked")
    public synchronized List<String> robotIds() {
        List<String> ids = new ArrayList<String>();
        Object robots = snapshot.get("robots");
        if (robots instanceof List) for (Object value : (List<?>) robots) {
            if (value instanceof Map) ids.add(String.valueOf(((Map<String, Object>) value).get("id")));
        }
        return Collections.unmodifiableList(ids);
    }

    /** Export frozen plans. Their simulated completion status is not real-world completion. */
    @SuppressWarnings("unchecked")
    public synchronized void exportPlans(String directory) throws IOException {
        Path destination = Paths.get(directory);
        Files.createDirectories(destination);
        Map<String, Object> fleet = engine.exportPlan();
        Files.write(destination.resolve("fleet_plan.json"), Json.stringify(fleet).getBytes(StandardCharsets.UTF_8));
        Object robots = fleet.get("robots");
        if (!(robots instanceof List)) throw new IllegalStateException("exportPlan has no robots list");
        for (Object value : (List<?>) robots) {
            if (!(value instanceof Map)) continue;
            Map<String, Object> robot = (Map<String, Object>) value;
            String id = String.valueOf(robot.get("robot_id"));
            if (!id.matches("[A-Za-z][A-Za-z0-9_]*")) throw new IllegalStateException("Unsafe robot id: " + id);
            Map<String, Object> plan = new LinkedHashMap<String, Object>();
            plan.put("schema_version", 1);
            plan.put("frame_id", fleet.get("frame_id"));
            plan.put("units", fleet.get("units"));
            plan.put("origin_wgs84", fleet.get("origin_wgs84"));
            plan.put("assignment", "frozen_export_from_simulation");
            plan.put("plan_type", fleet.get("plan_type"));
            plan.put("description", fleet.get("description"));
            plan.put("swath_m", fleet.get("swath_m"));
            plan.putAll(robot);
            Files.write(destination.resolve("plan_" + id + ".json"), Json.stringify(plan).getBytes(StandardCharsets.UTF_8));
        }
    }
}
