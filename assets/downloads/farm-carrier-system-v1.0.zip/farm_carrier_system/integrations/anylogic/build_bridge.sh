#!/usr/bin/env bash
set -euo pipefail
HERE="$(cd "$(dirname "$0")" && pwd)"
CORE_JAR="${1:?Usage: build_bridge.sh /absolute/path/to/core.jar}"
mkdir -p "$HERE/build/classes"
find "$HERE/src" -name '*.java' -print > "$HERE/build/sources.txt"
javac -source 8 -target 8 -encoding UTF-8 -cp "$CORE_JAR" -d "$HERE/build/classes" @"$HERE/build/sources.txt"
jar cf "$HERE/build/farm-anylogic-bridge.jar" -C "$HERE/build/classes" .
printf '%s\n' "Built $HERE/build/farm-anylogic-bridge.jar"
