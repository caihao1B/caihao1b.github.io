@echo off
setlocal
cd /d "%~dp0"
java -jar farm-carrier.jar --headless %*
exit /b %errorlevel%
