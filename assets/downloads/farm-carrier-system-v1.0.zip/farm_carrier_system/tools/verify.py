#!/usr/bin/env python3
"""Reproduce core, facade, Python contract and batch acceptance; Python 3.9+ stdlib."""
import importlib
import json
import os
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
REPORTS = ROOT / 'reports'
REPORTS.mkdir(exist_ok=True)


def run(args, expected=(0,)):
    result = subprocess.run(args, cwd=ROOT, capture_output=True, text=True, encoding='utf-8', timeout=120)
    if result.returncode not in expected:
        raise RuntimeError(f'Command failed ({result.returncode}): {args}\n{result.stdout}\n{result.stderr}')
    return result


def write(name, data):
    (REPORTS / name).write_text(json.dumps(data, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def main():
    core = json.loads(run(['java', '-Xmx512m', '-cp', 'farm-carrier.jar', 'farm.sim.CoreTests', 'maps/farm_map.json']).stdout)
    assert core['failed'] == 0
    write('core-tests.json', core)
    bridge = run(['java', '-cp', 'farm-carrier.jar', 'farm.anylogic.BridgeSmokeTest',
                  'maps/farm_map.json', 'runs/bridge_smoke']).stdout.strip()
    assert 'ANYLOGIC_BRIDGE_SMOKE_PASS' in bridge
    package = ROOT / 'integrations/ros2/farm_carrier_bridge'
    environment = dict(os.environ)
    environment['PYTHONPATH'] = str(package)
    tests = subprocess.run([sys.executable, '-m', 'unittest', 'discover', '-s', str(package / 'test'), '-v'],
                           cwd=ROOT, capture_output=True, text=True, timeout=60, env=environment)
    assert tests.returncode == 0, tests.stdout + tests.stderr
    (REPORTS / 'python-contract-tests.txt').write_text(tests.stdout + tests.stderr, encoding='utf-8')
    sys.path.insert(0, str(package))
    contract = importlib.import_module('farm_carrier_bridge.contract')
    imported = []
    for path in sorted((ROOT / 'runs/bridge_smoke').glob('plan_robot_*.json')):
        plan = contract.load_plan(path)
        imported.append({'robot_id': plan['robot_id'], 'segments': len(plan['segments']),
                         'nav2_goals': len(contract.tasks_for_plan(plan))})
    benchmark = []
    for scenario in ['normal', 'baseline', 'low_battery', 'harvest', 'robot_fault', 'blocked_return']:
        expected = 3 if scenario in ('robot_fault', 'blocked_return') else 0
        result = run(['java', '-Xmx512m', '-jar', 'farm-carrier.jar', '--headless', '--scenario', scenario,
                      '--output', 'runs/' + scenario], expected=(expected,))
        snapshot = json.loads((ROOT / 'runs' / scenario / 'snapshot.json').read_text())
        if expected == 0:
            assert snapshot['status'] == 'COMPLETED' and snapshot['coverage']['fraction'] == 1
            assert len(snapshot['carrier']['onboard']) == 3
        else:
            assert snapshot['status'] == 'WAITING_RECOVERY'
        assert not snapshot['metrics']['invariantViolations']
        benchmark.append({'scenario': scenario, 'status': snapshot['status'], **snapshot['metrics']})
    write('benchmark.json', {'assumptions': 'Deterministic demonstration model, one real field, three point robots. Fault waits freeze simulated time.', 'results': benchmark})
    validation = {'core_tests_passed': core['passed'], 'core_tests_failed': core['failed'],
                  'python_contract_suite': 'PASS', 'java_anylogic_facade': bridge,
                  'java_to_python_plan_import': imported, 'headless_scenarios': len(benchmark),
                  'runtime_validation': {'java': run(['java', '-version']).stderr.splitlines()[0],
                                         'anylogic_vendor_runtime': 'NOT_AVAILABLE_NOT_TESTED',
                                         'ros2_nav2_gazebo': 'NOT_AVAILABLE_NOT_TESTED',
                                         'physical_robot': 'NOT_TESTED'}}
    write('verification.json', validation)
    print(json.dumps(validation, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
