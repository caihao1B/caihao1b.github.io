#!/usr/bin/env python3
"""Convert the supplied agricultural scenario into a documented local demo map.

Standard library only. The original project is read as data, never executed.
The default input is a minimal, verbatim geometry excerpt bundled with the demo.
"""
from __future__ import annotations

import argparse
from collections import deque
import hashlib
import html
import json
import math
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
SOURCE_NAME = "verfahrenssimulation/farms/farms_EkoTech/E4A_Kleiner Modellbetrieb_Feld13_NurDrohne.json"


def load_json(path):
    raw = path.read_bytes()
    for encoding in ("utf-8-sig", "cp1252"):
        try:
            return json.loads(raw.decode(encoding)), encoding, hashlib.sha256(raw).hexdigest()
        except (UnicodeDecodeError, json.JSONDecodeError):
            continue
    raise ValueError("Input is not a supported UTF-8/CP1252 JSON scenario")


def write_json(path, obj):
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def cross(a, b, c):
    return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])


def distance_segment(p, a, b):
    vx, vy = b[0] - a[0], b[1] - a[1]
    norm = vx * vx + vy * vy
    t = max(0., min(1., ((p[0] - a[0]) * vx + (p[1] - a[1]) * vy) / norm)) if norm else 0.
    return math.hypot(p[0] - a[0] - t * vx, p[1] - a[1] - t * vy)


def in_polygon(p, poly):
    inside = False
    for i, a in enumerate(poly):
        b = poly[(i + 1) % len(poly)]
        if distance_segment(p, a, b) < 1e-8:
            return True
        if (a[1] > p[1]) != (b[1] > p[1]):
            x = a[0] + (p[1] - a[1]) * (b[0] - a[0]) / (b[1] - a[1])
            if x > p[0]:
                inside = not inside
    return inside


def area(poly):
    return abs(sum(a[0] * b[1] - b[0] * a[1] for a, b in zip(poly, poly[1:] + poly[:1]))) / 2


def local_projection(origin_lonlat):
    # Ellipsoidal local linearization; x east, y north. Not a UTM EPSG CRS.
    lon0, lat0 = origin_lonlat
    phi0 = math.radians(lat0)
    semimajor = 6378137.0
    eccentricity_sq = 6.6943799901413165e-3
    denominator = 1 - eccentricity_sq * math.sin(phi0) ** 2
    prime_vertical = semimajor / math.sqrt(denominator)
    meridian = semimajor * (1 - eccentricity_sq) / denominator ** 1.5

    def project(latlon):
        lat, lon = latlon
        return [round(math.radians(lon - lon0) * prime_vertical * math.cos(phi0), 6),
                round(math.radians(lat - lat0) * meridian, 6)]
    return project


def write_preview(out, model):
    field = model["fields"][0]
    poly = field["polygon"]
    road = model["roads"][0]["points"]
    pts = poly + road
    lo_x, hi_x = min(p[0] for p in pts) - 25, max(p[0] for p in pts) + 25
    lo_y, hi_y = min(p[1] for p in pts) - 25, max(p[1] for p in pts) + 25
    scale = min(870 / (hi_x - lo_x), 590 / (hi_y - lo_y))

    def xy(p):
        return 65 + (p[0] - lo_x) * scale, 90 + (hi_y - p[1]) * scale

    def path_points(points):
        return " ".join(f"{x:.2f},{y:.2f}" for x, y in map(xy, points))

    labels = []
    for p, label, color, dx, dy in [(model["depot"], "Demo depot", "#1d4ed8", 8, -10),
                                   (field["staging"], "Staging", "#b45309", 8, -7),
                                   (field["entry"], "Original entrance", "#b91c1c", 12, 19)]:
        x, y = xy(p)
        labels.append(f'<circle cx="{x:.2f}" cy="{y:.2f}" r="5" fill="{color}"/>'
                      f'<text x="{x + dx:.2f}" y="{y + dy:.2f}" fill="{color}" font-size="14">{label}</text>')
    cx, cy = xy([sum(p[0] for p in poly) / len(poly), sum(p[1] for p in poly) / len(poly)])
    bar_x, bar_y = 70, 685
    original = model["original_depot"]
    svg = f'''<svg xmlns="http://www.w3.org/2000/svg" width="1000" height="780" viewBox="0 0 1000 780">
<rect width="1000" height="780" fill="#f8fafc"/>
<g font-family="Arial, sans-serif" fill="#0f172a">
<text x="45" y="35" font-size="25" font-weight="bold">Feld 13: original boundary, synthetic access</text>
<text x="45" y="59" font-size="14">Local metres · east/right, north/up · planning map, not a surveyed road or SLAM map</text>
<polygon points="{path_points(poly)}" fill="#dcfce7" stroke="#15803d" stroke-width="2.5"/>
<polyline points="{path_points(road)}" fill="none" stroke="#93c5fd" stroke-width="{8 * scale:.2f}" stroke-linecap="round" stroke-linejoin="round"/>
<polyline points="{path_points(road)}" fill="none" stroke="#1d4ed8" stroke-width="2" stroke-dasharray="6 4"/>
<polygon points="{path_points(field['access_corridor'])}" fill="#fbbf24" fill-opacity="0.6" stroke="#b45309" stroke-width="1"/>
{''.join(labels)}
<text x="{cx:.2f}" y="{cy:.2f}" text-anchor="middle" font-size="24">{html.escape(field['name'])}</text>
<text x="{cx:.2f}" y="{cy + 27:.2f}" text-anchor="middle" font-size="16">{field['area_m2'] / 10000:.3f} ha · 4 original vertices</text>
<path d="M{bar_x} {bar_y}h{100 * scale:.2f}" fill="none" stroke="#0f172a" stroke-width="4"/>
<text x="{bar_x}" y="{bar_y - 9}" font-size="13">100 m</text>
<path d="M930 140v-40m0 0l-6 10m6-10l6 10" fill="none" stroke="#0f172a" stroke-width="2"/>
<text x="923" y="90" font-size="17">N</text>
<text x="45" y="725" font-size="14">Green: source field. Blue: synthetic demo road (8 m wide). Amber: synthetic access corridor (6 m wide).</text>
<text x="45" y="749" font-size="13">Original Hof1 kept separately: ({original[0]:.1f}, {original[1]:.1f}) m; no verified route to it is supplied.</text>
</g></svg>'''
    (out / "map_preview.svg").write_text(svg + "\n", encoding="utf-8")


def write_occupancy(out, model, resolution=1.0):
    field = model["fields"][0]
    points = field["polygon"] + [p for road in model["roads"] for p in road["points"]]
    origin_x = math.floor(min(p[0] for p in points) - 20)
    origin_y = math.floor(min(p[1] for p in points) - 20)
    width = math.ceil((max(p[0] for p in points) + 20 - origin_x) / resolution)
    height = math.ceil((max(p[1] for p in points) + 20 - origin_y) / resolution)

    def free(p):
        if in_polygon(p, field["polygon"]) or in_polygon(p, field["access_corridor"]):
            return True
        return any(distance_segment(p, a, b) <= road["width_m"] / 2
                   for road in model["roads"] for a, b in zip(road["points"], road["points"][1:]))

    # This array is in map order, y growing north; PGM rows are reversed below.
    grid = bytearray(width * height)
    for y in range(height):
        for x in range(width):
            p = [origin_x + (x + .5) * resolution, origin_y + (y + .5) * resolution]
            grid[y * width + x] = 254 if free(p) else 0

    def cell(p):
        x = int(math.floor((p[0] - origin_x) / resolution))
        y = int(math.floor((p[1] - origin_y) / resolution))
        return x, y

    start = cell(model["depot"])
    assert grid[start[1] * width + start[0]] == 254, "Depot is occupied"
    seen = {start}
    queue = deque([start])
    while queue:
        x, y = queue.popleft()
        for nx, ny in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
            if 0 <= nx < width and 0 <= ny < height and grid[ny * width + nx] == 254 and (nx, ny) not in seen:
                seen.add((nx, ny)); queue.append((nx, ny))
    checks = [model["depot"], field["staging"], field["entry"], field["access_path"][-1]]
    assert all(cell(p) in seen for p in checks), "Demo depot/road/corridor/field are disconnected"
    assert len(seen) == grid.count(254), "Disconnected free space in occupancy map"
    with (out / "farm_map.pgm").open("wb") as handle:
        handle.write(f"P5\n# SYNTHETIC planning occupancy; not SLAM or surveyed\n{width} {height}\n255\n".encode())
        for y in reversed(range(height)):
            handle.write(grid[y * width:(y + 1) * width])
    (out / "farm_map.yaml").write_text(
        "# Synthetic occupancy from source field and demo access. NOT a SLAM map.\n"
        "image: farm_map.pgm\nmode: trinary\nresolution: 1.0\n"
        f"origin: [{origin_x:.1f}, {origin_y:.1f}, 0.0]\n"
        "negate: 0\noccupied_thresh: 0.65\nfree_thresh: 0.196\n", encoding="utf-8")
    return {"resolution_m": resolution, "width": width, "height": height,
            "origin_local_m": [origin_x, origin_y], "connected_free_cells": len(seen),
            "all_free_cells_connected": True, "source": "synthetic planning occupancy; not SLAM"}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", nargs="?", type=Path, default=ROOT / "maps/source_field13_excerpt.json")
    parser.add_argument("--out-dir", type=Path, default=ROOT / "maps")
    args = parser.parse_args()
    data, encoding, input_sha = load_json(args.source)
    selected = [f for f in data["fields"] if f.get("name") == "Feld 13"]
    if len(selected) != 1:
        raise ValueError("This documented demo requires exactly one field named Feld 13")
    source_field = selected[0]
    if source_field.get("obstacles"):
        raise ValueError("Nonempty source obstacles need explicit conversion; refusing to omit them")
    origin = list(reversed(source_field["entrances"][0]))
    project = local_projection(origin)
    poly = [project(p) for p in source_field["edgePoints"]]
    signs = [cross(poly[i], poly[(i + 1) % len(poly)], poly[(i + 2) % len(poly)]) for i in range(len(poly))]
    assert all(v > 0 for v in signs) or all(v < 0 for v in signs), "Expected a simple convex field"
    entry, staging, depot = [0., 0.], [0., 15.], [-55., 30.]
    road = [depot, [-55., 20.], [0., 20.], staging]
    corridor = [[-3., 18.], [3., 18.], [3., -6.], [-3., -6.]]
    assert in_polygon(entry, poly) and in_polygon([0., -6.], poly), "Source entrance must connect to field"
    assert not in_polygon(staging, poly) and not in_polygon(depot, poly), "Demo parking must be outside field"
    for a, b in zip(road, road[1:]):
        for i in range(101):
            p = [a[j] + i / 100 * (b[j] - a[j]) for j in (0, 1)]
            assert not in_polygon(p, poly), "Synthetic road centreline intersects field"
    original_depot = project(data["locations"][0]["position"])
    source_crs = "WGS84 longitude/latitude inferred from geographic values and GeoPosition(lat,lon); source has no CRS declaration"
    model = {
        "schema_version": 1, "name": "Feld 13 carrier and ground robot demonstration",
        "units": "m", "axis_convention": "x east, y north", "origin_wgs84": origin,
        "projection": "WGS84 ellipsoidal local linearization at origin; not a UTM EPSG code",
        "depot": depot, "depot_source": "synthetic near-field demonstration depot",
        "original_depot": original_depot, "original_depot_name": data["locations"][0]["name"],
        "original_depot_wgs84": list(reversed(data["locations"][0]["position"])),
        "original_depot_used_for_mission": False,
        "fields": [{"id": "field13", "name": "Feld 13", "polygon": poly,
                    "area_m2": round(area(poly), 3), "staging": staging, "entry": entry,
                    "entrances": [project(p) for p in source_field["entrances"]],
                    "access_path": [staging, entry, [0., -6.]], "access_corridor": corridor,
                    "access_corridor_source": "synthetic demo access around the first original entrance",
                    "coverage_width_m": 9.0, "source": "original uploaded scenario boundary"}],
        "roads": [{"id": "demo_road_1", "points": road, "width_m": 8.0,
                   "source": "synthetic demo road"}], "obstacles": [],
        "assumptions": [source_crs, "No source obstacles; empty does not certify a real site is obstacle-free",
                        "Road, depot and access corridor are demonstration assumptions, not verified traversability",
                        "9 m coverage width comes from source configuration, not a calibrated ground-robot tool width"]}
    out = args.out_dir; out.mkdir(parents=True, exist_ok=True)
    write_json(out / "farm_map.json", model)
    features = []
    for i, source in enumerate(data["fields"]):
        ring = [list(reversed(p)) for p in source["edgePoints"]]
        if ring[0] != ring[-1]: ring.append(ring[0])
        features.append({"type": "Feature", "properties": {"id": f"original_field_{i}", "name": source["name"], "source": SOURCE_NAME, "source_coordinate_order": "latitude, longitude", "crs_status": source_crs}, "geometry": {"type": "Polygon", "coordinates": [ring]}})
        for j, point in enumerate(source.get("entrances", [])):
            features.append({"type": "Feature", "properties": {"name": f"{source['name']} entrance {j + 1}", "role": "original entrance"}, "geometry": {"type": "Point", "coordinates": list(reversed(point))}})
    for location in data["locations"]:
        features.append({"type": "Feature", "properties": {"name": location["name"], "role": "original farm depot", "used_for_demo_mission": False}, "geometry": {"type": "Point", "coordinates": list(reversed(location["position"]))}})
    write_json(out / "original_fields.geojson", {"type": "FeatureCollection", "features": features})
    write_preview(out, model)
    occupancy = write_occupancy(out, model)
    rows = ["# farm_map.tsv v1; UTF-8; local metres; x east, y north", "# type\tid\tindex\tx\ty"]
    rows += [f"ORIGIN_WGS84\tmap\t0\t{origin[0]}\t{origin[1]}", f"DEPOT\tdemo\t0\t{depot[0]}\t{depot[1]}", f"ORIGINAL_DEPOT\tHof1\t0\t{original_depot[0]}\t{original_depot[1]}"]
    for kind, points in (("FIELD", poly), ("STAGING", [staging]), ("ENTRY", [entry]), ("ACCESS_PATH", model["fields"][0]["access_path"]), ("ACCESS_CORRIDOR", corridor), ("ROAD", road)):
        rows.extend(f"{kind}\t{'demo_road_1' if kind == 'ROAD' else 'field13'}\t{i}\t{p[0]}\t{p[1]}" for i, p in enumerate(points))
    (out / "farm_map.tsv").write_text("\n".join(rows) + "\n", encoding="utf-8")
    summary = {"original_source": SOURCE_NAME, "original_encoding": "CP1252", "input_file": args.source.name, "input_encoding": encoding, "input_sha256": input_sha,
               "original_source_sha256": data.get("_provenance", {}).get("original_source_sha256", input_sha),
               "source_schema": ["name", "jahr", "szenario", "locations", "vehicles", "attachments", "processChains", "fields"],
               "field_geometry_keys": ["edgePoints", "entrances", "obstacles"], "source_coordinate_order": "latitude, longitude",
               "export_coordinate_order": "longitude, latitude", "crs_status": source_crs,
               "selected_field": "Feld 13", "polygon_vertices": len(poly), "convex": True, "area_m2": model["fields"][0]["area_m2"],
               "source_entrances": len(source_field["entrances"]), "source_obstacles": len(source_field.get("obstacles", [])),
               "original_depot_distance_from_entry_m": round(math.hypot(*original_depot), 3),
               "demo_depot_distance_from_entry_m": round(math.hypot(*depot), 3),
               "default_coverage_width_m": 9, "coverage_width_status": "source configuration; not ground-robot calibration",
               "original_depot_used_for_mission": False, "synthetic_elements": ["near-field demo depot", "8 m demo road", "6 m access corridor", "staging point", "occupancy free/occupied mask"],
               "checks": {"entry_inside_field": True, "staging_and_depot_outside_field": True, "road_centreline_outside_field": True, "road_endpoint_equals_staging": True, "access_path_uses_original_entrance": True}, "occupancy": occupancy}
    write_json(out / "source_summary.json", summary)
    print(json.dumps({"output": str(out), "field_area_ha": model["fields"][0]["area_m2"] / 10000,
                      "original_depot_distance_m": summary["original_depot_distance_from_entry_m"], "occupancy": occupancy}, indent=2))


if __name__ == "__main__":
    main()
