#!/usr/bin/env python3
"""Package project with per-file hashes. Does not bundle installed dependencies or original archive."""
import hashlib
import json
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parents[1]
excluded = {'build', '__pycache__', 'node_modules', '.git', '.venv'}
manifest = root / 'release_manifest.json'


def include(path):
    parts = path.relative_to(root).parts
    return (path.is_file() and not path.is_symlink() and not excluded.intersection(parts)
            and path.suffix not in ('.pyc', '.zip') and path != manifest
            and not (len(parts) > 1 and parts[0] == 'runs' and parts[1] == 'dashboard'))


files = sorted(p for p in root.rglob('*') if include(p))
records = [{'path': p.relative_to(root).as_posix(), 'bytes': p.stat().st_size,
            'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
manifest.write_text(json.dumps({'version': '1.0.0', 'entrypoint': 'farm-carrier.jar',
                               'java_bytecode_target': 8, 'files': records},
                              ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
destination = root.parent / 'farm_carrier_system_v1.0.zip'
with zipfile.ZipFile(destination, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for p in files + [manifest]:
        z.write(p, root.name + '/' + p.relative_to(root).as_posix())
with zipfile.ZipFile(destination) as z:
    assert z.testzip() is None
print(json.dumps({'file': str(destination), 'files': len(files) + 1,
                  'bytes': destination.stat().st_size,
                  'sha256': hashlib.sha256(destination.read_bytes()).hexdigest()}, indent=2))
