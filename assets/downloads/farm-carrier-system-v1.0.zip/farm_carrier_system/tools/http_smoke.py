#!/usr/bin/env python3
"""Exercise the local dashboard API. Start the JAR first. Only stdlib is required."""
import argparse
import json
import time
import urllib.request
import urllib.error
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=8765)
    args = parser.parse_args()
    base = f'http://127.0.0.1:{args.port}'
    root = Path(__file__).resolve().parents[1]
    checks = []

    def request(path, data=None, auth=True, expect=200):
        headers = {}
        if data is not None:
            headers['Content-Type'] = 'application/json'
            if auth:
                headers['X-Farm-Token'] = token
        req = urllib.request.Request(base + path,
                                     data=None if data is None else json.dumps(data).encode(),
                                     headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=45) as response:
                code, text, mime = response.status, response.read().decode(), response.headers['Content-Type']
        except urllib.error.HTTPError as exc:
            code, text, mime = exc.code, exc.read().decode(), exc.headers['Content-Type']
        assert code == expect, (path, code, expect, text[:200])
        return json.loads(text) if 'application/json' in mime else text

    def command(command, **kwargs):
        return request('/api/command', {'command': command, **kwargs})

    def state():
        return request('/api/state')

    def check(name, condition):
        assert condition, name
        checks.append({'test': name, 'result': 'PASS'})

    def complete_check(name):
        s = state()
        check(name, s['status'] == 'COMPLETED' and s['coverage']['fraction'] == 1
              and len(s['carrier']['onboard']) == len(s['robots'])
              and not s['metrics']['invariantViolations'])
        return s

    token = request('/api/config')['token']
    check('dashboard_assets_served', '<canvas' in request('/')
          and 'use strict' in request('/app.js') and ':root' in request('/style.css'))
    request('/api/command', {'command': 'reset'}, auth=False, expect=403)
    check('mutation_requires_local_session_token', True)
    command('reset', scenario='normal', robots=3)
    request('/api/command', {'command': 'reset', 'scenario': 'invalid'}, expect=400)
    request('/api/command', {'command': 'reset', 'robots': 0}, expect=400)
    check('invalid_configuration_preserves_mission', state()['scenario'] == 'normal' and len(state()['robots']) == 3)
    command('step')
    check('single_step_advances_half_second', state()['time'] == .5)
    command('speed', value=30)
    command('start')
    time.sleep(.35)
    command('pause')
    paused = state()['time']
    time.sleep(.15)
    check('start_pause_freezes_time', paused > .5 and state()['time'] == paused)
    command('fault_robot', robotId='robot_1')
    command('block_route')
    command('clear_route')
    check('clearing_route_does_not_clear_device_fault', state()['status'] == 'WAITING_RECOVERY')
    command('clear_fault', robotId='robot_1')
    check('explicit_fault_clear_resumes', state()['status'] == 'RUNNING')
    command('run_to_end')
    complete_check('normal_mission_all_workers_recovered')
    command('export')
    files = ['metrics.json', 'events.csv', 'mission_plan.json', 'snapshot.json', 'plan_robot_1.json']
    check('run_export_written', all((root / 'runs/dashboard' / f).is_file() for f in files))
    command('reset', scenario='harvest', robots=3)
    command('run_to_end')
    s = complete_check('harvest_mission_completed')
    check('harvest_cargo_transferred_to_carrier', s['carrier']['cargoKg'] > 0 and all(r['cargoKg'] == 0 for r in s['robots']))
    command('reset', scenario='normal', robots=3)
    for _ in range(10):
        command('step')
    command('recall')
    command('run_to_end')
    s = state()
    check('recall_does_not_claim_full_coverage', s['status'] == 'CANCELLED'
          and s['coverage']['fraction'] < 1 and len(s['carrier']['onboard']) == 3)
    command('reset', scenario='robot_fault', robots=3)
    command('run_to_end')
    s = state()
    check('fault_scenario_waits_for_repair', s['status'] == 'WAITING_RECOVERY')
    faulty = next(r['id'] for r in s['robots'] if r['state'] == 'FAULT')
    command('clear_fault', robotId=faulty)
    command('run_to_end')
    complete_check('fault_scenario_recovers_after_acknowledgement')
    command('reset', scenario='blocked_return', robots=3)
    command('run_to_end')
    check('blocked_scenario_waits_for_clearance', state()['status'] == 'WAITING_RECOVERY')
    command('clear_route')
    command('run_to_end')
    complete_check('blocked_scenario_recovers_after_clearance')
    command('reset', scenario='normal', robots=3)
    result = {'suite': 'Loopback HTTP application acceptance', 'passed': len(checks), 'failed': 0,
              'checks': checks, 'browser_rendering': 'Separate test; HTTP checks do not prove visual layout.'}
    destination = root / 'reports/http-tests.json'
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps({'http_checks_passed': len(checks), 'failed': 0, 'report': str(destination)}, indent=2))


if __name__ == '__main__':
    main()
