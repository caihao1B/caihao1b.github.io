/* Optional UI acceptance: npm-installed playwright + a browser. Not needed to run the app. */
const {chromium}=require('playwright');
const fs=require('fs');
const path=require('path');
const assert=require('assert');
(async()=>{
 const output=path.resolve('reports');fs.mkdirSync(output,{recursive:true});
 const options={headless:true,args:['--no-sandbox','--disable-dev-shm-usage']};
 if(process.env.FARM_BROWSER_EXECUTABLE)options.executablePath=process.env.FARM_BROWSER_EXECUTABLE;
 const browser=await chromium.launch(options);
 const page=await browser.newPage({viewport:{width:1440,height:1000},deviceScaleFactor:1});
 const errors=[],checks=[];page.on('pageerror',e=>errors.push(e.message));
 async function state(){return page.evaluate(()=>fetch('/api/state').then(r=>r.json()));}
 async function waitState(predicate,timeout=30000){const end=Date.now()+timeout;while(Date.now()<end){const s=await state();if(predicate(s))return s;await page.waitForTimeout(100);}throw new Error('Timed out waiting for mission state');}
 async function waitStatus(value){await waitState(s=>s.status===value);await page.waitForTimeout(450);}
 async function reset(scenario='normal'){await page.selectOption('#scenario',scenario);await page.click('#reset');await page.waitForTimeout(450);}
 function pass(test){checks.push({test,result:'PASS'});}
 try{
  await page.goto(process.env.FARM_APP_URL||'http://127.0.0.1:8765',{waitUntil:'domcontentloaded'});
  await page.waitForFunction(()=>document.getElementById('connection').textContent==='本地服务已连接');
  await page.evaluate(()=>document.fonts.ready);
  await reset();
  assert.equal(await page.locator('canvas').count(),1);assert.equal((await state()).coverage.fraction,0);
  pass('dashboard_loaded_with_canvas_and_live_state');
  await page.waitForSelector('#toast.visible',{state:'hidden',timeout:6000});
  await page.screenshot({path:path.join(output,'dashboard-ready.png'),fullPage:true});
  await page.selectOption('#speed','300');await page.click('#play');
  await waitState(s=>s.time>1300,20000);
  await page.click('#play');await page.waitForTimeout(400);
  const active=await state();assert(active.coverage.fraction>0&&active.coverage.fraction<1);assert.equal(active.playing,false);
  pass('play_speed_pause_updates_actual_worker_positions');
  await page.screenshot({path:path.join(output,'dashboard-running.png'),fullPage:true});
  await page.click('#zoom-in');await page.click('#fit');await page.click('#show-paths');await page.click('#show-paths');
  pass('map_zoom_fit_and_path_visibility');
  await page.click('#finish');await waitStatus('COMPLETED');
  assert.equal((await state()).carrier.onboard.length,3);assert.equal((await state()).coverage.fraction,1);
  assert((await page.textContent('#mission-status')).includes('任务已完成'));
  pass('fast_forward_completes_and_renders_all_workers_onboard');
  await page.screenshot({path:path.join(output,'dashboard-completed.png'),fullPage:true});
  const downloadPromise=page.waitForEvent('download');await page.click('#download-plan');const download=await downloadPromise;
  const downloaded=await download.path();assert.equal(JSON.parse(fs.readFileSync(downloaded,'utf8')).robots.length,3);
  pass('plan_download_is_valid_fleet_json');
  await page.click('#export');await page.waitForFunction(()=>document.getElementById('toast').textContent.includes('runs/dashboard'));
  pass('export_control_displays_destination');
  await reset('blocked_return');await page.click('#finish');await waitStatus('WAITING_RECOVERY');
  assert((await page.textContent('#mission-status')).includes('等待人工恢复'));
  await page.click('#clear-route');await page.click('#finish');await waitStatus('COMPLETED');
  pass('blocked_route_requires_explicit_clearance_via_UI');
  await reset('robot_fault');await page.click('#finish');await waitStatus('WAITING_RECOVERY');
  const faulty=(await state()).robots.find(r=>r.state==='FAULT').id;await page.selectOption('#fault-robot',faulty);await page.click('#repair');await page.click('#finish');await waitStatus('COMPLETED');
  pass('fault_requires_correct_robot_repair_via_UI');
  await reset();await page.click('#recall');await page.click('#finish');await waitStatus('CANCELLED');
  assert((await page.textContent('#mission-status')).includes('召回已完成'));
  pass('recall_rendered_as_cancelled_not_completed');
  await reset();
  for(const width of [1440,1024,390]){
    await page.setViewportSize({width,height:width<500?844:1000});await page.waitForTimeout(250);
    const dims=await page.evaluate(()=>({width:document.documentElement.clientWidth,scroll:document.documentElement.scrollWidth,canvas:document.getElementById('map').clientWidth}));
    assert(dims.scroll<=dims.width+1,JSON.stringify(dims));assert(dims.canvas>250);
    pass(`responsive_layout_${width}px_no_page_overflow`);
    if(width===390)await page.screenshot({path:path.join(output,'dashboard-mobile.png'),fullPage:true});
  }
  assert.deepEqual(errors,[]);pass('no_browser_javascript_errors');
  fs.writeFileSync(path.join(output,'browser-tests.json'),JSON.stringify({browser:browser.version(),passed:checks.length,failed:0,checks,pageErrors:errors},null,2));
  console.log(JSON.stringify({passed:checks.length,failed:0,browser:browser.version(),screenshots:'reports/dashboard-*.png'}));
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exit(1)});
