import javax.tools.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.jar.*;
import java.util.stream.*;

/** Run with JDK 17+: java tools/Build.java. Produces a Java 8 compatible JAR. */
class Build {
    public static void main(String[] args) throws Exception {
        Path root=Paths.get("").toAbsolutePath();
        Path classes=root.resolve("build/classes");
        if(Files.exists(classes))try(Stream<Path> paths=Files.walk(classes)){
            for(Path p:paths.sorted(Comparator.reverseOrder()).collect(Collectors.toList()))Files.delete(p);
        }
        Files.createDirectories(classes);
        JavaCompiler compiler=ToolProvider.getSystemJavaCompiler();
        if(compiler==null)throw new IllegalStateException("Build requires a JDK with the Java compiler. To run the included JAR, only Java 8+ is needed.");
        List<File> source=new ArrayList<>();
        for(String dir:Arrays.asList("src/main/java","integrations/anylogic/src"))try(Stream<Path> files=Files.walk(root.resolve(dir))){
            files.filter(p->p.toString().endsWith(".java")).sorted().forEach(p->source.add(p.toFile()));
        }
        try(StandardJavaFileManager manager=compiler.getStandardFileManager(null,Locale.ROOT,StandardCharsets.UTF_8)){
            List<String> options=Arrays.asList("--release","8","-encoding","UTF-8","-d",classes.toString());
            boolean ok=compiler.getTask(null,manager,null,options,null,manager.getJavaFileObjectsFromFiles(source)).call();
            if(!ok)throw new IllegalStateException("Compilation failed");
        }
        Path jar=root.resolve("farm-carrier.jar");
        try(JarOutputStream out=new JarOutputStream(Files.newOutputStream(jar))) {
            JarEntry manifest=new JarEntry("META-INF/MANIFEST.MF");manifest.setTime(0);out.putNextEntry(manifest);
            out.write("Manifest-Version: 1.0\r\nMain-Class: farm.sim.App\r\nImplementation-Version: 1.0.0\r\n\r\n".getBytes(StandardCharsets.UTF_8));out.closeEntry();
            try(Stream<Path> files=Files.walk(classes)){
                for(Path p:files.filter(Files::isRegularFile).sorted().collect(Collectors.toList())){
                    JarEntry entry=new JarEntry(classes.relativize(p).toString().replace('\\','/'));entry.setTime(0);out.putNextEntry(entry);Files.copy(p,out);out.closeEntry();
                }
            }
        }
        System.out.println("Compiled "+source.size()+" source files for Java 8.");
        System.out.println("Created "+jar+" ("+Files.size(jar)+" bytes)");
        System.out.println("Run: java -jar farm-carrier.jar");
    }
}
