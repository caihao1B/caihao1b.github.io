@echo off
setlocal
cd /d "%~dp0"
java tools\Build.java
if errorlevel 1 (
  echo Build requires JDK 17 or newer. See README_ZH.md.
  pause
  exit /b 1
)
